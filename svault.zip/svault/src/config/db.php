<?php
// returns $client and $db
require_once __DIR__ . '/../bootstrap.php';
$uri = $_ENV['MONGO_URI'] ?? 'mongodb://127.0.0.1:27017';
$dbName = $_ENV['MONGO_DB'] ?? 'svault';
$client = new MongoDB\Client($uri);
$db = $client->selectDatabase($dbName);
