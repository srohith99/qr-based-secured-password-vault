<?php
use Endroid\QrCode\Builder\Builder;
use Endroid\QrCode\Writer\PngWriter;

function build_qr_dataurl($text, $size = 300) {
    $result = Builder::create()
        ->writer(new PngWriter())
        ->data($text)
        ->size($size)
        ->margin(10)
        ->build();

    return 'data:image/png;base64,' . base64_encode($result->getString());
}
