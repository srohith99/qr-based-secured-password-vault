<?php
// AES-256-CBC per-entry IV + HMAC (SHA256). Use ENCRYPTION_MASTER_KEY from .env
function get_master_key_raw(){
    $k = $_ENV['ENCRYPTION_MASTER_KEY'] ?? '';
    if (strlen($k) < 32) {
        // pad or hash to 32 bytes
        return hash('sha256', $k, true);
    }
    return substr($k,0,32);
}

function encrypt_entry($plaintext){
    $key = get_master_key_raw();
    $iv = random_bytes(16); // 128-bit IV for AES-256-CBC
    $cipher = openssl_encrypt($plaintext, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    $ct_b64 = base64_encode($cipher);
    $iv_b64 = base64_encode($iv);
    // HMAC over iv + ct
    $hmac = hash_hmac('sha256', $iv_b64 . '|' . $ct_b64, $key, true);
    $hmac_b64 = base64_encode($hmac);
    return json_encode(['iv'=>$iv_b64,'ct'=>$ct_b64,'hmac'=>$hmac_b64]);
}

function decrypt_entry($payload_json){
    $key = get_master_key_raw();
    $p = json_decode($payload_json, true);
    if (!$p || !isset($p['iv']) || !isset($p['ct']) || !isset($p['hmac'])) return false;
    $calc = base64_encode(hash_hmac('sha256', $p['iv'] . '|' . $p['ct'], $key, true));
    if (!hash_equals($p['hmac'], $calc)) return false; // tamper check
    $iv = base64_decode($p['iv']);
    $ct = base64_decode($p['ct']);
    $plain = openssl_decrypt($ct, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    return $plain;
}
