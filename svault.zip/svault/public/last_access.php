<?php
require_once __DIR__ . '/../src/config/db.php';
date_default_timezone_set('Asia/Kolkata');

$user_id = $_GET['user_id'] ?? null;
if (!$user_id) {
    echo "Missing user_id";
    exit;
}

try {
    $uid = new MongoDB\BSON\ObjectId($user_id);
} catch (Exception $e) {
    echo "Invalid user ID";
    exit;
}

// -------- Fetch Username --------
$username = "Unknown User";
try {
    $u = $db->users->findOne(
        ['_id' => $uid],
        ['projection' => ['username' => 1]]
    );
    if ($u && isset($u['username'])) $username = $u['username'];
} catch (Exception $e) {}


// -------- Fetch Last Stored Accurate GPS Location --------
$loc = $db->access_locations->findOne(
    ['user_id' => $uid],
    ['sort' => ['timestamp' => -1]] // latest reading
);

if (!$loc) {
    $lat = $lon = $accuracy = null;
    $time_ist = "No location stored yet";
} else {
    $lat = $loc['lat'];
    $lon = $loc['lon'];
    $accuracy = $loc['accuracy'];

    $ts = $loc['timestamp']->toDateTime();
    $ts->setTimezone(new DateTimeZone("Asia/Kolkata"));
    $time_ist = $ts->format("Y-m-d H:i:s");
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Last Access Location</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
body{
    font-family: Inter, system-ui;
    background: #eef7ff;
    margin: 0;
    padding: 20px;
}
.box{
    max-width: 750px;
    margin: auto;
    background: white;
    padding: 22px;
    border-radius: 12px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.08);
}
h2{
    margin-top: 0;
    text-align:center;
}
.item{
    padding: 10px 0;
    border-bottom: 1px solid #eee;
}
.value{
    font-weight: 700;
}
.map{
    width:100%;
    height:350px;
    border-radius: 12px;
    margin-top: 18px;
}
.back{
    display:block;
    margin-top:20px;
    background:#2a9df4;
    color:white;
    text-align:center;
    padding:10px;
    border-radius:10px;
    text-decoration:none;
    font-weight:700;
}
</style>
</head>

<body>

<div class="box">
    <h2>📍 Last Access Location</h2>

    <div class="item">Username:
        <span class="value"><?php echo htmlspecialchars($username); ?></span>
    </div>

    <div class="item">Last Access (IST):
        <span class="value"><?php echo $time_ist; ?></span>
    </div>

    <div class="item">Accuracy:
        <span class="value">
        <?php echo $accuracy !== null ? $accuracy . " meters" : "N/A"; ?>
        </span>
    </div>

    <div class="item">Coordinates:
        <span class="value">
        <?php echo ($lat && $lon) ? "$lat, $lon" : "No location available"; ?>
        </span>
    </div>

    <?php if ($lat && $lon): ?>
        <iframe class="map"
        src="https://www.openstreetmap.org/export/embed.html?bbox=<?php 
            echo ($lon - 0.005) . ',' . ($lat - 0.005) . ',' . ($lon + 0.005) . ',' . ($lat + 0.005); 
        ?>&layer=mapnik&marker=<?php echo $lat . ',' . $lon; ?>">
        </iframe>
    <?php else: ?>
        <p style="margin-top:15px; color:#555;">No GPS location stored yet. Open vault again and allow location access.</p>
    <?php endif; ?>

    <a class="back" href="vault.php?user_id=<?php echo $user_id; ?>">⬅ Back to Vault</a>
</div>

</body>
</html>
