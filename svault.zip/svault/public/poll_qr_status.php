<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../src/config/db.php';
require_once __DIR__ . '/../src/bootstrap.php';
require_once __DIR__ . '/../src/utils/crypto.php';

$token = $_GET['token'] ?? '';
if (!$token) { echo json_encode(['ok'=>false]); exit; }

$qr = $db->qr_sessions->findOne(['token'=>$token]);
if (!$qr) { echo json_encode(['ok'=>false]); exit; }

if (!empty($qr['used']) && isset($qr['password_id'])) {
    $p = $db->passwords->findOne(['_id'=>$qr['password_id']]);
    if ($p) {
        $plain = decrypt_entry($p['encrypted_payload']);
        echo json_encode(['ok'=>true,'revealed'=>true,'password'=>$plain]);
        exit;
    }
}
echo json_encode(['ok'=>true,'used'=>!empty($qr['used'])]);
