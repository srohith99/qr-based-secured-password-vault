<?php
require_once __DIR__ . '/../src/config/db.php';
require_once __DIR__ . '/../src/bootstrap.php';

$user_id = $_GET['user_id'] ?? null;
$password_id = $_GET['password_id'] ?? null;
if (!$user_id || !$password_id) { echo "provide user_id & password_id\n"; exit; }

try {
    $uid = new MongoDB\BSON\ObjectId($user_id);
    $pid = new MongoDB\BSON\ObjectId($password_id);
} catch (Exception $e) { echo "Invalid IDs\n"; exit; }

$record = $db->passwords->findOne(['_id'=>$pid,'user_id'=>$uid]);
if (!$record) { echo "Record not found\n"; exit; }

$payload = $record['encrypted_payload'];
echo "RAW PAYLOAD:\n";
var_dump($payload);

// try json decode
$data = json_decode($payload, true);
echo "json_decode error? " . json_last_error() . " (" . json_last_error_msg() . ")\n";
if (!$data) { echo "payload not valid JSON\n"; exit; }

echo "Fields present: " . implode(', ', array_keys($data)) . "\n";
echo "iv len(base64): " . strlen($data['iv']) . "\n";
echo "ct len(base64): " . strlen($data['ct']) . "\n";
echo "hmac len(base64): " . strlen($data['hmac']) . "\n";

$user_key = hash('sha256', (string)$uid . '_master_key_salt', true);

// helper attempts
function try_decrypt($iv_b64, $ct_b64, $key, $flag) {
    $iv = base64_decode($iv_b64, true);
    $ct = base64_decode($ct_b64, true);
    if ($iv === false) { echo "iv base64_decode failed\n"; return false; }
    // if $ct is false, maybe ct was not double-base64 encoded. Pass raw $ct_b64 to openssl_decrypt
    $attemptCt = $ct === false ? $ct_b64 : $ct;
    $pt = openssl_decrypt($attemptCt, 'AES-256-CBC', $key, $flag, $iv);
    return $pt === false ? false : $pt;
}

// try variations
echo "\nAttempt 1: (openssl expects base64 -> flag 0) with single base64 decode of ct:\n";
$pt = try_decrypt($data['iv'], $data['ct'], $user_key, 0);
var_dump($pt);

echo "\nAttempt 2: (openssl expects RAW -> OPENSSL_RAW_DATA) decode ct and use raw:\n";
$pt2 = try_decrypt($data['iv'], $data['ct'], $user_key, OPENSSL_RAW_DATA);
var_dump($pt2);

echo "\nAttempt 3: treat ct as double-base64 (decode twice) then RAW flag:\n";
$ct_once = base64_decode($data['ct'], true);
$ct_twice = $ct_once !== false ? base64_decode($ct_once, true) : false;
if ($ct_twice !== false) {
    $iv = base64_decode($data['iv'], true);
    $pt3 = openssl_decrypt($ct_twice, 'AES-256-CBC', $user_key, OPENSSL_RAW_DATA, $iv);
    var_dump($pt3);
} else {
    echo "double decode not possible\n";
}

echo "\nAttempt 4: print hmac bytes (base64 decode) length:\n";
var_dump(base64_decode($data['hmac'], true));
