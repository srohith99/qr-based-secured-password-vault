<?php
require_once __DIR__ . '/../src/config/db.php';
require_once __DIR__ . '/../src/bootstrap.php';

$user_id = $_GET['user_id'] ?? null;
if (!$user_id) { 
    echo 'Missing user_id parameter — authenticate via QR'; 
    exit; 
}
try {
    $uid = new MongoDB\BSON\ObjectId($user_id);
} catch (Exception $e) { 
    echo 'invalid user id'; 
    exit; 
}

// Fetch soft-deleted passwords (recently deleted)
$cursor = $db->passwords->find([
    'user_id' => $uid, 
    'deleted_at' => ['$exists' => true]
], ['sort' => ['deleted_at' => -1]]); // Most recent first
$deleted_passwords = $cursor->toArray();

// Debug log (remove after testing)
error_log("Deleted passwords count for user $user_id: " . count($deleted_passwords));
if (empty($deleted_passwords)) {
    error_log("No deleted passwords found. Raw query filter: user_id = $uid, deleted_at exists=true");
    // Optional: Log all passwords to check if deleted_at is set
    $all_passwords = $db->passwords->find(['user_id' => $uid])->toArray();
    error_log("All passwords count: " . count($all_passwords) . ". Sample: " . json_encode(array_slice($all_passwords, 0, 2)));
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Recently Deleted - Secured Vault</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
  /* --------- Colors & layout --------- */
  :root{
    --bg1: #e6f9ff;
    --bg2: #ffffff;
    --accent: #00b4ff;
    --accent-2: #2a9df4;
    --muted: #6b7280;
    --card: #ffffff;
    --glass: rgba(255,255,255,0.75);
    --danger: #e02b2b;
    --success: #10b981;
  }
  *{box-sizing:border-box}
  html,body{height:100%;margin:0;font-family:Inter,system-ui,Segoe UI,Roboto,Arial;background:linear-gradient(135deg,var(--bg1),var(--bg2));background-size:300% 300%;animation:bgFlow 12s linear infinite;color:#072033;}
  @keyframes bgFlow{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}

  /* Topbar */
  .topbar{display:flex;justify-content:space-between;align-items:center;padding:14px 22px;background:rgba(255,255,255,0.9);backdrop-filter:blur(6px);box-shadow:0 6px 20px rgba(8,18,28,0.05);position:sticky;top:0;z-index:30;}
  .topbar .title{font-weight:700;font-size:1.2rem}
  .topbar .controls{display:flex;gap:10px;align-items:center}

  /* Main layout */
  .container{max-width:1200px;margin:22px auto;padding:18px;display:grid;grid-template-columns:260px 1fr;gap:20px}
  @media (max-width:920px){ .container{grid-template-columns:1fr} }

  /* Sidebar */
  .sidebar{background:var(--card);padding:16px;border-radius:12px;box-shadow:0 10px 30px rgba(2,6,12,0.06)}
  .nav{display:block;padding:10px;border-radius:10px;color:var(--accent);text-decoration:none;font-weight:600;margin-bottom:8px}
  .nav:hover{background:#eef9ff}

  /* Grid of password cards */
  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:18px;padding:6px}
  .card{background:var(--card);padding:16px;border-radius:12px;box-shadow:0 8px 24px rgba(8,18,28,0.06);transition:transform .18s ease; opacity: 0.8; border-left: 4px solid var(--danger);}
  .card:hover{transform:translateY(-6px)}
  .entry h4{margin:0 0 8px;font-size:1.05rem}
  .masked{font-size:1.4rem;letter-spacing:5px;color:#0b2130;opacity:0.6;margin-bottom:12px}
  .actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
  .deleted-meta {font-size:0.85rem; color:var(--danger); margin-top:4px; font-style:italic;}

  /* QR Modal (not used here, but kept for consistency) */
  .modal{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(3,7,13,0.42);z-index:80}
  .modal-box{width:380px;background:linear-gradient(180deg,rgba(255,255,255,0.98),#fff);padding:18px;border-radius:12px;box-shadow:0 10px 30px rgba(3,7,13,0.2);text-align:center}
  #qr-area img{width:240px}
  .qr-count{color:var(--muted);font-weight:600;margin-top:8px}

  /* Webcam hologram panel (bottom-left on large screens) */
  .webcam{
  position:fixed;
  left:10px;
  bottom:10px;
  width:200px;
  background:linear-gradient(180deg,rgba(255,255,255,0.92),rgba(255,255,255,0.88));
  padding:8px;
  border-radius:10px;
  box-shadow:0 8px 30px rgba(2,6,12,0.12);
  z-index:70;
}
.webcam .preview{
  position:relative;
  width:100%;
  height:100px;
  border-radius:8px;
  overflow:hidden;
  border:1px solid rgba(0,150,220,0.06);
}
#webcam{
  width:100%;
  height:100%;
  object-fit:cover;
  display:block;
}
#overlay{
  position:absolute;
  left:0;
  top:0;
  width:100%;
  height:100%;
}
#det-status{
  margin-top:6px;
  font-weight:700;
  color:var(--muted);
  text-align:center;
  font-size: 0.8em;
}

  /* Reveal animated password card (center) - not used here */
  .reveal-card{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%) scale(.95);width:360px;border-radius:16px;padding:18px;color:#fff;z-index:90;box-shadow:0 20px 60px rgba(2,6,12,0.35);opacity:0;transition:transform .28s,opacity .28s}
  .reveal-card.visible{opacity:1;transform:translate(-50%,-50%) scale(1)}
  .reveal-inner{padding:6px;border-radius:12px;background:linear-gradient(135deg,#00b4ff,#2a9df4);background-size:200% 200%;animation:revealGrad 6s ease infinite}
  @keyframes revealGrad{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}
  .reveal-title{font-weight:800;font-size:1rem}
  .reveal-pass{font-weight:900;font-family:monospace;font-size:1.6rem;margin:12px 0;letter-spacing:1px}
  .reveal-meta{font-weight:600;opacity:0.95}
  .copy-btn{background:rgba(255,255,255,0.12);border:0;padding:10px 12px;border-radius:10px;color:#fff;font-weight:700;cursor:pointer;transition:transform .12s}
  .copy-btn:active{transform:scale(.98)}

  /* small helper */
  .small-muted{color:var(--muted);font-weight:600}

  /* Success message */
  .success-msg {
    grid-column: 1 / -1;
    background: #ecfdf5;
    color: #065f46;
    padding: 12px;
    border-radius: 8px;
    text-align: center;
    font-weight: 600;
    margin-bottom: 18px;
  }

  /* dark mode */
  .dark body, .dark{ background: linear-gradient(145deg,#071322,#081827);}
  .dark .card{ background: rgba(6,24,38,0.85); color:#dff6ff; border-left-color: #ef4444; }
  .dark .sidebar, .dark .modal-box, .dark .webcam { background: rgba(6,24,38,0.85) }
  .dark .masked{ color:#cfeaff }
  .dark .small-muted{ color:#a9dff6 }
  .dark .success-msg { background: #064e3b; color: #d1fae5; }
  .dark .deleted-meta { color: #f87171; }

  /* small UI niceties */
  .btn { background:linear-gradient(90deg,var(--accent),var(--accent-2)); color:white; padding:8px 12px; border-radius:8px; border:0; font-weight:700; cursor:pointer; text-decoration:none; display:inline-block; text-align:center; }
  .btn.small{padding:6px 8px;font-size:.9rem}
  .btn.danger { background: var(--danger); }
  .btn.restore { background: var(--success); }
</style>
</head>
<body>

<header class="topbar">
  <div class="title">🗑️ Recently Deleted</div>
  <div class="controls">
    <button id="themeToggle" class="btn small">Toggle Dark</button>
    <a href="lock_vault.php?user_id=<?php echo urlencode($user_id); ?>" class="btn small">Lock</a>
    <a href="vault.php?user_id=<?php echo urlencode($user_id); ?>" class="btn small">Back to Vault</a>
  </div>
</header>

<main class="container">
  <aside class="sidebar">
    <a class="nav" href="vault.php?user_id=<?php echo $user_id; ?>">🏠 Vault</a>
    <a class="nav" href="add_password.php?user_id=<?php echo $user_id; ?>">➕ Add password</a>
    <a class="nav" href="security_logs.php?user_id=<?php echo $user_id; ?>">📊 Security logs</a>
    <p style="margin-top:12px;color:var(--muted);font-weight:600;">Last login: <?php echo date('Y-m-d H:i'); ?></p>
  </aside>

  <section class="grid">
    <?php if (isset($_GET['restored'])): ?>
      <div class="success-msg">✅ Password restored successfully!</div>
    <?php endif; ?>
    <?php if (empty($deleted_passwords)): ?>
      <div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: var(--muted);">
        <h3>No recently deleted passwords.</h3>
        <p>Deleted items are kept here for 30 days before permanent removal.</p>
        <p style="font-size:0.9rem; opacity:0.7;">(Check PHP error log for debug info if expected items missing.)</p>
      </div>
    <?php else: ?>
      <?php foreach($deleted_passwords as $p): ?>
        <article class="entry card">
          <h4><?php echo htmlentities($p['site_name']); ?></h4>
          <div class="masked">••••••••</div>
          <div class="deleted-meta">Deleted: <?php 
            if (isset($p['deleted_at']) && $p['deleted_at'] instanceof MongoDB\BSON\UTCDateTime) {
                echo date('Y-m-d H:i', $p['deleted_at']->toDateTime()->getTimestamp());
            } else {
                echo 'Unknown (check log)';
            }
          ?></div>
          <div class="actions">
            <a href="restore_password.php?user_id=<?php echo $user_id; ?>&password_id=<?php echo (string)$p['_id']; ?>" class="btn small restore" onclick="return confirm('Restore this password to your vault?');">Restore</a>
            <button class="btn small danger" onclick="if(confirm('Permanently delete this? No recovery possible.')) { window.location.href='permanent_delete.php?user_id=<?php echo $user_id; ?>&password_id=<?php echo (string)$p['_id']; ?>'; }">Permanent Delete</button>
          </div>
        </article>
      <?php endforeach; ?>
    <?php endif; ?>
  </section>
</main>

<!-- Webcam preview container (for consistency, though not used) -->
<div class="webcam" id="webcam-panel" style="display:none;">
  <div class="preview">
    <video id="webcam" autoplay muted playsinline></video>
    <canvas id="overlay"></canvas>
  </div>
  <div id="det-status">Loading camera...</div>
</div>

<script>
// Simple theme toggle
document.getElementById('themeToggle').addEventListener('click', () => {
  document.body.classList.toggle('dark');
  localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
});
</script>

</body>
</html>