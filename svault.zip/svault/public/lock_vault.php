<?php
require_once __DIR__ . '/../src/config/db.php';
$user_id = $_GET['user_id'] ?? null;
if ($user_id) {
    $db->audit_logs->insertOne(['user_id'=> new MongoDB\BSON\ObjectId($user_id), 'event_type'=>'lock','event_data'=>'user locked','ts'=>new MongoDB\BSON\UTCDateTime()]);
}
header('Location: index.php');
