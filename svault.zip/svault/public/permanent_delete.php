<?php
require_once __DIR__ . '/../src/config/db.php';
require_once __DIR__ . '/../src/bootstrap.php';

$user_id = $_GET['user_id'] ?? null;
$password_id = $_GET['password_id'] ?? null;

if (!$user_id || !$password_id) {
    http_response_code(400);
    echo 'Missing user_id or password_id parameter';
    exit;
}

try {
    $uid = new MongoDB\BSON\ObjectId($user_id);
    $pid = new MongoDB\BSON\ObjectId($password_id);
} catch (Exception $e) {
    http_response_code(400);
    echo 'Invalid user ID or password ID';
    exit;
}

// Find and permanently delete the soft-deleted password
$delete_result = $db->passwords->deleteOne([
    '_id' => $pid,
    'user_id' => $uid,
    'deleted_at' => ['$exists' => true]  // Ensure it's soft-deleted
]);

if ($delete_result->getDeletedCount() === 1) {
    // Log the permanent deletion to audit
    $db->audit_logs->insertOne([
        'user_id' => $uid,
        'event_type' => 'password_permanent_delete',
        'event_data' => [
            'password_id' => (string)$pid,
            'deleted_at' => new MongoDB\BSON\UTCDateTime()
        ],
        'timestamp' => new MongoDB\BSON\UTCDateTime()
    ]);

    // Redirect back to deleted passwords list with success message
    header("Location: deleted_passwords.php?user_id=" . urlencode($user_id) . "&permanently_deleted=1");
    exit;
} else {
    http_response_code(404);
    echo 'Password not found or not eligible for permanent deletion';
    exit;
}
?>