<?php
require_once __DIR__ . '/../src/config/db.php';
require_once __DIR__ . '/../src/bootstrap.php';

$user_id = $_GET['user_id'] ?? null;
$password_id = $_GET['password_id'] ?? null;

if (!$user_id || !$password_id) { 
    header("Location: vault.php?user_id=" . urlencode($user_id ?? '') . "&error=missing_params");
    exit; 
}

try {
    $uid = new MongoDB\BSON\ObjectId($user_id);
    $pid = new MongoDB\BSON\ObjectId($password_id);
} catch (Exception $e) { 
    header("Location: vault.php?user_id=" . urlencode($user_id) . "&error=invalid_id");
    exit; 
}

// Fetch to confirm exists and get site_name for log
$current = $db->passwords->findOne(['_id' => $pid, 'user_id' => $uid, 'deleted_at' => ['$exists' => false]]);
if (!$current) { 
    header("Location: vault.php?user_id=" . urlencode($user_id) . "&error=not_found");
    exit; 
}

$update_result = $db->passwords->updateOne(
    ['_id' => $pid, 'user_id' => $uid, 'deleted_at' => ['$exists' => false]],
    ['$set' => ['deleted_at' => new MongoDB\BSON\UTCDateTime()]]
);

if ($update_result->getModifiedCount() === 1) {
    // Log the soft deletion to audit
    $db->audit_logs->insertOne([
        'user_id' => $uid,
        'event_type' => 'password_soft_delete',
        'event_data' => [
            'password_id' => (string)$pid,
            'site_name' => $current['site_name'],
            'deleted_at' => new MongoDB\BSON\UTCDateTime()
        ],
        'timestamp' => new MongoDB\BSON\UTCDateTime()
    ]);

    // Optional debug log
    error_log("Soft deleted password ID $password_id for user $user_id: " . $current['site_name']);

    header("Location: vault.php?user_id=" . urlencode($user_id) . "&deleted=1");
} else {
    header("Location: vault.php?user_id=" . urlencode($user_id) . "&error=delete_failed");
}

exit;
?>