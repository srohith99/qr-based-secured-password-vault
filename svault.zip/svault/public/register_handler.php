<?php
require_once __DIR__ . '/../src/config/db.php';
require_once __DIR__ . '/../src/bootstrap.php';

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';
$device_id = trim($_POST['device_id'] ?? '');

if (!$username || !$password || !$device_id) { die('missing fields'); }

$users = $db->users;
$exists = $users->findOne(['username'=>$username]);
if ($exists) { die('username exists'); }

$pwdHash = password_hash($password, PASSWORD_BCRYPT);
$qr_secret = bin2hex(random_bytes(16));

$res = $users->insertOne([
    'username'=>$username,
    'password_hash'=>$pwdHash,
    'device_id'=>$device_id,
    'qr_secret'=>$qr_secret,
    'created_at'=>new MongoDB\BSON\UTCDateTime()
]);

header('Location: index.php?registered=1');
