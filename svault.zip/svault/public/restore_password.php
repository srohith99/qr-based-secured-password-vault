<?php
require_once __DIR__ . '/../src/config/db.php';
require_once __DIR__ . '/../src/bootstrap.php';

$user_id = $_GET['user_id'] ?? null;
$password_id = $_GET['password_id'] ?? null;

if (!$user_id || !$password_id) { header("Location: deleted_passwords.php?error=missing"); exit; }

try {
    $uid = new MongoDB\BSON\ObjectId($user_id);
    $pid = new MongoDB\BSON\ObjectId($password_id);
} catch (Exception $e) { header("Location: deleted_passwords.php?error=invalid"); exit; }

$result = $db->passwords->updateOne(
    ['_id' => $pid, 'user_id' => $uid, 'deleted_at' => ['$exists' => true]],
    ['$unset' => ['deleted_at' => '']]
);

if ($result->getModifiedCount() === 1) {
    $db->audit_logs->insertOne([
        'user_id' => $uid,
        'event_type' => 'password_restore',
        'event_data' => ['password_id' => (string)$pid],
        'timestamp' => new MongoDB\BSON\UTCDateTime()
    ]);
    header("Location: deleted_passwords.php?user_id=" . urlencode($user_id) . "&restored=1");
} else {
    header("Location: deleted_passwords.php?user_id=" . urlencode($user_id) . "&error=failed");
}
exit;
?>