<?php
require_once __DIR__ . '/../src/config/db.php';
require_once __DIR__ . '/../src/bootstrap.php';
require_once __DIR__ . '/../src/utils/crypto.php';

$site = $_POST['site_name'] ?? '';
$url = $_POST['site_url'] ?? '';
$pass = $_POST['password'] ?? '';
$user_id = $_POST['user_id'] ?? '';
if (!$site || !$pass || !$user_id) die('missing');

$enc = encrypt_entry($pass);
$db->passwords->insertOne([
    'user_id'=> new MongoDB\BSON\ObjectId($user_id),
    'site_name'=>$site,
    'site_url'=>$url,
    'encrypted_payload'=>$enc,
    'created_at'=>new MongoDB\BSON\UTCDateTime()
]);

header('Location: vault.php?user_id=' . urlencode($user_id));
