/* vault.js
   Handles:
   - Reveal QR generation & modal
   - Polling for QR verification
   - Password reveal card (scramble + gradient + copy + confetti + sound)
   - TF.js camera detection (coco-ssd) to detect mobile phones and lock
   - Dark mode toggle
*/

const QR_POLL_INTERVAL = 1500;   // ms
const QR_TIMEOUT = 35000;       // ms (stop polling)
const REVEAL_SECONDS = 12;      // seconds to show password

// ====== DOM helpers ======
const $ = id => document.getElementById(id);
const revealCard = $('reveal-card');
const revealedPass = $('revealed-pass');
const revealTimer = $('reveal-timer');
const copyBtn = $('copy-pass');
const qrModal = $('qr-modal');
const qrArea = $('qr-area');
const qrCount = $('qr-count');
const detStatus = $('det-status');
const themeToggle = $('themeToggle');

// ====== theme ======
function applyTheme(dark){
  if(dark) document.documentElement.classList.add('dark'); else document.documentElement.classList.remove('dark');
  localStorage.setItem('sv_dark', dark ? '1' : '0');
}
themeToggle.addEventListener('click', ()=> applyTheme(!(localStorage.getItem('sv_dark')==='1')));
applyTheme(localStorage.getItem('sv_dark')==='1');

// ====== QR reveal flow ======
document.addEventListener('DOMContentLoaded', ()=> {
  document.querySelectorAll('.reveal').forEach(btn => {
    btn.addEventListener('click', async () => {
      const password_id = btn.dataset.id;
      const urlParams = new URLSearchParams(location.search);
      const user_id = urlParams.get('user_id') || null;
      if(!user_id){ alert('Missing user_id — authenticate first'); return; }

      try {
        const resp = await fetch(`reveal_request.php?password_id=${encodeURIComponent(password_id)}&user_id=${encodeURIComponent(user_id)}`);
        const json = await resp.json();
        if(json.ok){
          openQrModal(json.qr, json.expires, json.token);
          pollQr(json.token);
        } else {
          alert('Failed to create QR: ' + (json.error || 'unknown'));
        }
      } catch(e){
        console.error(e);
        alert('Network error creating QR');
      }
    });
  });

  $('close-qr').addEventListener('click', ()=> { qrModal.style.display = 'none'; });
});

// show modal with QR image and expiry
function openQrModal(qrDataUrl, expiresIso, token){
  qrArea.innerHTML = `<img src="${qrDataUrl}" alt="QR">`;
  qrCount.innerText = `Expires: ${new Date(expiresIso).toLocaleTimeString()}`;
  qrModal.style.display = 'flex';
}

// poll for token verification; when verified, server returns password
async function pollQr(token){
  const start = Date.now();
  const interval = setInterval(async ()=>{
    try {
      const res = await fetch(`poll_qr_status.php?token=${encodeURIComponent(token)}`);
      const j = await res.json();
      if(j.revealed){
        clearInterval(interval);
        qrModal.style.display = 'none';
        showPassword(j.password);
        return;
      }
      // stop after timeout
      if(Date.now() - start > QR_TIMEOUT){
        clearInterval(interval);
        qrModal.style.display = 'none';
        alert('QR timed out — please regenerate');
      }
    } catch(e){
      clearInterval(interval);
      qrModal.style.display = 'none';
      alert('Network error while polling QR status');
    }
  }, QR_POLL_INTERVAL);
}

// ====== Show reveal card with scramble animation, confetti, sound, copy and auto-hide ======
function showPassword(password){
  // set text masked initially
  revealedPass.innerText = '••••••••';
  // show card
  revealCard.classList.add('visible');

  // scramble -> reveal
  scrambleText(revealedPass, password, 900);
  // play sound
  playPing();

  // confetti
  try { confetti({ particleCount: 60, spread: 55 }); } catch(e){}

  // copy button
  copyBtn.onclick = async () => {
    try {
      await navigator.clipboard.writeText(password);
      copyBtn.innerText = 'Copied ✓';
      setTimeout(()=> copyBtn.innerText = 'Copy', 1600);
    } catch(e) {
      alert('Copy failed');
    }
  };

  // countdown
  let timeLeft = REVEAL_SECONDS;
  revealTimer.innerText = `${timeLeft}s remaining`;
  const countdown = setInterval(()=>{
    timeLeft--;
    revealTimer.innerText = `${timeLeft}s remaining`;
    if(timeLeft <= 0){
      clearInterval(countdown);
      hideRevealCard();
    }
  }, 1000);
}

function hideRevealCard(){
  revealCard.classList.remove('visible');
  revealedPass.innerText = '••••••••';
  revealTimer.innerText = `${REVEAL_SECONDS}s remaining`;
  copyBtn.innerText = 'Copy';
}

// scramble animation (random chars → reveal)
function scrambleText(el, finalText, duration=900){
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const start = performance.now();
  function frame(now){
    const t = Math.min(1, (now - start) / duration);
    const reveal = Math.floor(t * finalText.length);
    let out = '';
    for(let i=0;i<finalText.length;i++){
      if(i < reveal) out += finalText[i];
      else out += chars[Math.floor(Math.random()*chars.length)];
    }
    el.innerText = out;
    if(t < 1) requestAnimationFrame(frame);
    else el.innerText = finalText;
  }
  requestAnimationFrame(frame);
}

// quick sound ping
function playPing(){
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = 'sine';
    o.frequency.value = 880;
    g.gain.value = 0.0018;
    o.connect(g); g.connect(ctx.destination);
    o.start();
    setTimeout(()=>{ o.stop(); ctx.close(); }, 160);
  } catch(e){
    // ignore
  }
}

// ====== TF.js camera detection (mobile devices detection triggers lock) ======
(async function cameraAndDetection(){
  const video = document.getElementById('webcam');
  const canvas = document.getElementById('overlay');
  const ctx = canvas.getContext('2d');

  // set canvas size to video container size after metadata loads
  function resizeCanvas(){
    canvas.width = video.videoWidth || canvas.clientWidth;
    canvas.height = video.videoHeight || canvas.clientHeight;
  }

  try {
    const stream = await navigator.mediaDevices.getUserMedia({video:{ facingMode: "user" }, audio:false});
    video.srcObject = stream;
    await new Promise(res => video.onloadedmetadata = res);
    resizeCanvas();
  } catch(e) {
    detStatus.innerText = 'Camera unavailable';
    return;
  }

  detStatus.innerText = 'Camera active — monitoring';

  // load TF model
  let model;
  try { model = await cocoSsd.load(); } catch(e){ console.warn('model load fail', e); detStatus.innerText = 'AI model failed'; return; }

  // detection loop
  async function loop(){
    const preds = await model.detect(video);
    ctx.clearRect(0,0,canvas.width,canvas.height);

    let mobileDetected = false;
    preds.forEach(p=>{
      const [x,y,w,h] = p.bbox;
      // scale bounding if canvas differs
      ctx.strokeStyle = 'rgba(255,0,0,0.85)';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, w, h);
      ctx.fillStyle = 'rgba(255,0,0,0.85)';
      ctx.font = '14px Inter';
      ctx.fillText(`${p.class} ${(p.score*100).toFixed(0)}%`, x, y - 6);

      if(p.class === 'cell phone' || p.class === 'mobile phone') mobileDetected = true;
    });

    if(mobileDetected){
      detStatus.innerText = 'Mobile detected — locking...';
      // blur reveal card and invalidate tokens (best-effort UI)
      if(revealCard.classList.contains('visible')){
        revealedPass.innerText = '••••••••';
      }
      // post detection log (non-blocking)
      try{
        fetch('detection_trigger.php', {
          method:'POST',
          headers:{ 'Content-Type':'application/json' },
          body: JSON.stringify({ event:'mobile_detected', time: (new Date()).toISOString() })
        }).catch(()=>{});
      }catch(e){}

      // short delay then redirect to login (lock)
      setTimeout(()=> { location.href = 'index.php'; }, 800);
      return;
    } else {
      detStatus.innerText = 'No mobile detected';
    }

    requestAnimationFrame(loop);
  }

  loop();
})();

// ====== poll for page visibility and blur handling (optional) ======
document.addEventListener('visibilitychange', ()=>{
  if(document.hidden){
    // optionally auto-hide reveal card for safety
    if(revealCard.classList.contains('visible')) hideRevealCard();
  }
});
