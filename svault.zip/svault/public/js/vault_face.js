// public/js/vault_face.js
(async function(){

  const MATCH_THRESHOLD = 0.45;
  const NO_FACE_TIMEOUT = 3;
  const MATCH_CONFIRM_TIME = 700;

  let storedEmbedding = null;
  let lastFaceAt = Date.now();
  let locked = false;

  // Load face embedding
  async function loadEmbedding(){
    const r = await fetch('fetch_embedding.php');
    const j = await r.json();
    if (!j.ok) return null;
    return j.embedding;
  }

  // Load models
  await Promise.all([
    faceapi.nets.ssdMobilenetv1.loadFromUri("./models"),
    faceapi.nets.faceLandmark68Net.loadFromUri("./models"),
    faceapi.nets.faceRecognitionNet.loadFromUri("./models")
  ]);

  document.getElementById('faceLabel').innerText = "Models loaded — starting camera";

  storedEmbedding = await loadEmbedding();
  if (!storedEmbedding){
    document.getElementById('faceLabel').innerText = "❌ No enrolled face — vault locked";
    document.querySelectorAll('.revealBtn').forEach(b=>{
      b.disabled = true;
      b.innerText = "No face enrolled";
    });
    return;
  }

  const video = document.getElementById('faceVideo');

  // Start camera
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    video.srcObject = stream;
    await new Promise(r=> video.onloadedmetadata = r);
  } catch (e){
    document.getElementById('faceLabel').innerText = "Camera access denied";
    return;
  }

  document.getElementById('faceLabel').innerText = "Camera active — verifying face...";

  function dist(a,b){
    let s=0;
    for (let i=0;i<a.length;i++){
      const d = a[i]-b[i];
      s += d*d;
    }
    return Math.sqrt(s);
  }

  const overlay = document.getElementById("overlay");
  const ctx = overlay ? overlay.getContext("2d") : null;

  async function loop(){
    if (locked) return;

    const dets = await faceapi
      .detectAllFaces(video)
      .withFaceLandmarks()
      .withFaceDescriptors();

    if (ctx){
      ctx.clearRect(0,0,overlay.width,overlay.height);
    }

    if (!dets.length){
      if (Date.now() - lastFaceAt > NO_FACE_TIMEOUT*1000){
        lock("no_face_detected");
      }
      requestAnimationFrame(loop);
      return;
    }

    lastFaceAt = Date.now();

    if (dets.length > 1){
      lock("multiple_faces");
      return;
    }

    const desc = dets[0].descriptor;
    const d = dist(desc, storedEmbedding);

    if (ctx){
      const box = dets[0].detection.box;
      ctx.strokeStyle = d <= MATCH_THRESHOLD ? "lime" : "red";
      ctx.lineWidth = 2;
      ctx.strokeRect(box.x, box.y, box.width, box.height);
    }

    if (d <= MATCH_THRESHOLD){
      document.querySelectorAll(".revealBtn").forEach(b=>{
        b.disabled = false;
        b.innerText = "Reveal (Scan QR)";
      });
      document.querySelectorAll(".face-status").forEach(s=>{
        s.innerText = "Face verified";
      });
    } else {
      lock("unknown_face");
      return;
    }

    requestAnimationFrame(loop);
  }

  requestAnimationFrame(loop);

  async function lock(reason){
    if (locked) return;
    locked = true;

    document.querySelectorAll('.revealBtn').forEach(b=>{
      b.disabled = true;
      b.innerText = "Locked";
    });

    document.querySelectorAll('.face-status').forEach(s=>{
      s.innerText = "Locked — " + reason;
    });

    await fetch("lock_vault.php");
    window.location = "index.php";
  }

  // COCO SSD (optional)
  try {
    const cam = video; // use same camera
    const model = await cocoSsd.load();

    (async function detectPhone(){
      const preds = await model.detect(cam);
      
      if (preds.some(p=> p.class === "cell phone" || p.class === "person")){
        await fetch("detection_trigger.php", {
          method:"POST",
          headers:{"Content-Type":"application/json"},
          body: JSON.stringify({ preds: preds.map(p=>p.class) })
        });
        lock("camera_threat");
        return;
      }

      setTimeout(detectPhone, 800);
    })();
  } catch (e){
    console.warn("coco-ssd failed", e);
  }

})();
