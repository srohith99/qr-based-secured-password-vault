<?php
// security_dashboard.php
require_once __DIR__ . '/../src/config/db.php'; // adjust path if needed

$user_id = $_GET['user_id'] ?? null;
if (!$user_id) { echo "Missing user_id"; exit; }
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Security Score Dashboard</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
:root{--bg:#05070d;--neon:#00eaff;--card:#0f1622;--muted:#7aa6c7;--good:#00ff99;--warn:#ffbb33;--bad:#ff4466}
body{margin:0;background:radial-gradient(circle at top,#0a0f18,#02040a 70%);font-family:Inter, sans-serif;color:#dff6ff}
.topbar{display:flex;justify-content:space-between;padding:16px 22px;background:#060b12;border-bottom:1px solid var(--neon);box-shadow:0 0 12px #00b7ff33}
.title{font-weight:800;color:var(--neon)}
.container{max-width:1100px;margin:34px auto;padding:20px;border-radius:12px;background:linear-gradient(180deg,#08101a,#061018);border:1px solid #122333;box-shadow:0 0 18px #002b44}
.grid{display:grid;grid-template-columns:300px 1fr;gap:18px}
@media(max-width:920px){.grid{grid-template-columns:1fr}}
.card{background:#07101a;padding:16px;border-radius:10px;border:1px solid #123044}
.kpi{display:flex;flex-direction:column;gap:12px}
.kpi .item{padding:12px;border-radius:8px;background:linear-gradient(180deg,#031018,#08151e);border:1px solid #123344}
.gauge{height:12px;background:#041017;border-radius:8px;overflow:hidden}
.gauge > i{display:block;height:100%;width:0;transition:width .4s ease}
.list{list-style:none;padding:0;margin:0}
.list li{padding:8px;border-radius:8px;margin-bottom:8px;background:linear-gradient(180deg,#04101a,#071523);border:1px solid #102634}
.small{color:var(--muted);font-size:0.92rem}
.bad{color:var(--bad)} .warn{color:var(--warn)} .good{color:var(--good)}
.footer-note{margin-top:14px;color:var(--muted);font-size:0.9rem}
.btn{padding:8px 12px;border:1px solid var(--neon);color:var(--neon);background:transparent;border-radius:8px;text-decoration:none;font-weight:700}
</style>
</head>
<body>
<header class="topbar">
  <div class="title">📊 Security Score Dashboard</div>
  <div>
    <a class="btn" href="vault.php?user_id=<?php echo urlencode($user_id); ?>">Back to Vault</a>
  </div>
</header>

<main class="container">
  <div class="grid">
    <section class="card kpi">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div><strong>Vault Health</strong><div class="small">Summary of your password hygiene</div></div>
        <div id="overall-grade" style="font-size:1.2rem;font-weight:900">—</div>
      </div>

      <div style="margin-top:12px">
        <div class="small">Overall security score</div>
        <div class="gauge" style="margin-top:8px"><i id="overall-gauge"></i></div>
        <div style="display:flex;justify-content:space-between;margin-top:8px">
          <div class="small">Weak</div><div id="weak-count" class="small">0</div>
        </div>
        <div style="display:flex;justify-content:space-between;margin-top:6px">
          <div class="small">Reused</div><div id="reused-count" class="small">0</div>
        </div>
        <div style="display:flex;justify-content:space-between;margin-top:6px">
          <div class="small">Long (>=12)</div><div id="long-count" class="small">0</div>
        </div>
      </div>

      <div class="footer-note">
        Score components: weak passwords, reused credentials, length profile, and breach exposure (if available).
      </div>
    </section>

    <section class="card">
      <strong>Actionable Insights</strong>
      <ul class="list" id="insights" style="margin-top:12px">
        <li class="small">Loading insights…</li>
      </ul>

      <div style="margin-top:12px; display:flex; gap:8px">
        <a class="btn" id="run-scan">Run Live Scan</a>
        <a class="btn" id="open-analyzer" href="strength_analyzer.php?user_id=<?php echo urlencode($user_id); ?>">Open Analyzer</a>
        <a class="btn" id="open-breach" href="breach_checker.php?user_id=<?php echo urlencode($user_id); ?>">Open Breach Checker</a>
      </div>

      <div class="footer-note" style="margin-top:12px">
        Note: the live scan uses non-sensitive metrics stored in the server. Raw passwords are never exposed.
      </div>
    </section>
  </div>

  <div style="margin-top:18px" class="card">
    <strong>Top Weak Passwords</strong>
    <ul id="weak-list" class="list" style="margin-top:12px">
      <li class="small">Loading…</li>
    </ul>
  </div>
</main>

<script>
/*
  This dashboard requests metrics from metrics_api.php
  - If you already log password metrics during add (entropy/score), metrics_api will return detailed metrics.
  - If not, metrics_api will still return safe aggregates.
*/
const userId = "<?php echo addslashes($user_id); ?>";
async function loadMetrics(){
  const res = await fetch('metrics_api.php?user_id='+encodeURIComponent(userId));
  const data = await res.json();

  // Overall score 0-100
  const score = Math.round(data.overall_score || 0);
  const grade = score >= 80 ? 'A' : score >= 60 ? 'B' : score >= 40 ? 'C' : 'D';
  document.getElementById('overall-grade').textContent = grade + ' ('+score+')';
  document.getElementById('overall-gauge').style.width = Math.max(5, score)+'%';
  document.getElementById('overall-gauge').style.background = score >= 80 ? 'linear-gradient(90deg,#00ff99,#00b7ff)' : score >= 60 ? 'linear-gradient(90deg,#ffd166,#ff7a18)' : 'linear-gradient(90deg,#ff4d4d,#ff355e)';

  document.getElementById('weak-count').textContent = data.weak_count || 0;
  document.getElementById('reused-count').textContent = data.reused_count || 0;
  document.getElementById('long-count').textContent = data.long_count || 0;

  const insights = data.insights || ['No insights available.'];
  const insEl = document.getElementById('insights');
  insEl.innerHTML = '';
  insights.forEach(i => {
    const li = document.createElement('li');
    li.className = 'small';
    li.textContent = '• ' + i;
    insEl.appendChild(li);
  });

  const weakList = document.getElementById('weak-list');
  weakList.innerHTML = '';
  if ((data.top_weak || []).length === 0) {
    weakList.innerHTML = '<li class="small">No weak passwords recorded.</li>';
  } else {
    data.top_weak.forEach(x => {
      const li = document.createElement('li');
      li.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center"><div><strong>${x.site||'site'}</strong><div class="small">${x.note||''}</div></div><div class="small ${x.level==='weak'?'bad':(x.level==='reused'?'warn':'good')}">${x.level.toUpperCase()}</div></div>`;
      weakList.appendChild(li);
    });
  }
}

document.getElementById('run-scan').addEventListener('click', async ()=>{
  document.getElementById('insights').innerHTML = '<li class="small">Running live scan…</li>';
  await fetch('metrics_api.php?user_id='+encodeURIComponent(userId)+'&rescan=1');
  await loadMetrics();
});

loadMetrics();
</script>
</body>
</html>
