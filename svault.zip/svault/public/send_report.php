<?php
// send_report.php
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../src/config/db.php';

// PHPMailer (if installed)
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
}

// ---------- SMTP SETTINGS (EDIT THESE) ----------
$smtp = [
    'host' => 'smtp.gmail.com',
    'port' => 587,
    'username' => 'studybin24@gmail.com',   // your Gmail
    'password' => 'kqtx adae wuqq lmuk',      // your Gmail App Password
    'secure' => 'tls',
    'from_email' => 'vaultnoreply@gmail.com',
    'from_name' => 'Secured Vault System',
];

// fallback if user email is not stored in DB:
$fallback_recipient = 'studybin24@gmail.com';
// ------------------------------------------------

// Read input
$raw = file_get_contents("php://input");
if (!$raw) {
    echo json_encode(['ok'=>false, 'error'=>'no_input']);
    exit;
}

$data = json_decode($raw, true);
if (!$data || !isset($data['user_id'])) {
    echo json_encode(['ok'=>false, 'error'=>'invalid_data']);
    exit;
}

$user_id = $data['user_id'];

// Convert user_id to Mongo ObjectId
try {
    $uid = new MongoDB\BSON\ObjectId($user_id);
} catch (Exception $e) {
    echo json_encode(['ok'=>false, 'error'=>'invalid_user_id']);
    exit;
}

// Get email from DB (optional)
$to_email = $fallback_recipient;
try {
    if (isset($db->users)) {
        $u = $db->users->findOne(['_id'=>$uid], ['projection'=>['email'=>1]]);
        if ($u && isset($u['email']) && strlen($u['email']) > 3) {
            $to_email = $u['email'];
        }
    }
} catch (Exception $e) {
    // ignore, continue with fallback
}


// ---------- FORMAT PLAIN TABLE EMAIL ----------
$body =
"============================================\n".
"         SECURED VAULT — SESSION REPORT     \n".
"============================================\n".
"User ID           : {$user_id}\n".
"Session Start     : " . ($data['session_start_iso'] ?? 'Unknown') . "\n".
"Session End       : " . ($data['session_end_iso'] ?? 'Unknown') . "\n".
"Active Duration   : " . ($data['active_seconds'] ?? 0) . " seconds\n".
"Passwords Revealed: " . ($data['reveal_count'] ?? 0) . "\n".
"Vault Locks       : " . ($data['lock_count'] ?? 0) . "\n".
"Panic Triggered   : " . (!empty($data['panic']) ? 'YES' : 'NO') . "\n".
"--------------------------------------------\n".
"Device Info\n".
"User-Agent        : " . ($data['device']['userAgent'] ?? 'Unknown') . "\n".
"Platform          : " . ($data['device']['platform'] ?? 'Unknown') . "\n".
"--------------------------------------------\n".
"IP Address        : " . ($_SERVER['REMOTE_ADDR'] ?? 'Unknown') . "\n".
"Report Time (UTC) : " . gmdate('Y-m-d H:i:s') . "\n".
"============================================\n";


// ---------- SEND EMAIL ----------
$email_sent = false;
$sent_error = null;

if (class_exists('PHPMailer\\PHPMailer\\PHPMailer')) {
    try {
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);

        $mail->isSMTP();
        $mail->Host = $smtp['host'];
        $mail->SMTPAuth = true;
        $mail->Username = $smtp['username'];
        $mail->Password = $smtp['password'];
        $mail->SMTPSecure = $smtp['secure'];
        $mail->Port = $smtp['port'];

        $mail->setFrom($smtp['from_email'], $smtp['from_name']);
        $mail->addAddress($to_email);

        $mail->Subject = "Your Vault Session Report";
        $mail->Body = $body;
        $mail->AltBody = $body;

        $mail->send();
        $email_sent = true;

    } catch (Exception $e) {
        $email_sent = false;
        $sent_error = $e->getMessage();
    }

} else {
    // Fallback: PHP mail()
    $headers = "From: {$smtp['from_name']} <{$smtp['from_email']}>\r\n";
    $headers .= "Content-Type: text/plain; charset=utf-8\r\n";

    if (mail($to_email, "Your Vault Session Report", $body, $headers)) {
        $email_sent = true;
    } else {
        $email_sent = false;
        $sent_error = "mail() failed. Install PHPMailer.";
    }
}


// ---------- OPTIONAL: SAVE IN DB ----------
try {
    if (isset($db->session_logs)) {
        $db->session_logs->insertOne([
            'user_id' => $uid,
            'created_at' => new MongoDB\BSON\UTCDateTime(),
            'session' => $data,
            'email_sent' => $email_sent
        ]);
    }
} catch (Exception $e) {}


// ---------- RESPONSE ----------
echo json_encode([
    'ok' => true,
    'email_sent' => $email_sent,
    'error' => $sent_error
]);
exit;
