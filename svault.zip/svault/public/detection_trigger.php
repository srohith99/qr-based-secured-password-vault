<?php
require_once __DIR__ . '/../src/config/db.php';
require_once __DIR__ . '/../src/bootstrap.php';
header('Content-Type: application/json');
$data = json_decode(file_get_contents('php://input'), true);
if (!$data) { http_response_code(400); echo json_encode(['ok'=>false]); exit; }
$user_id = $data['user_id'] ?? null;
$pid = $data['password_id'] ?? null;
$pred = json_encode($data['predictions'] ?? []);
$db->detection_logs->insertOne([
   'user_id'=> $user_id ? new MongoDB\BSON\ObjectId($user_id) : null,
   'password_id'=> $pid ? new MongoDB\BSON\ObjectId($pid) : null,
   'predictions'=>$pred,
   'ts'=> new MongoDB\BSON\UTCDateTime()
]);
// add audit log
$db->audit_logs->insertOne(['user_id'=> $user_id ? new MongoDB\BSON\ObjectId($user_id) : null, 'event_type'=>'detection','event_data'=>$pred,'ts'=>new MongoDB\BSON\UTCDateTime()]);
echo json_encode(['ok'=>true]);
