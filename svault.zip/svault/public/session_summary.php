<?php
$user_id = $_GET['user_id'] ?? null;
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Session Summary</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
body{
    font-family: Inter, system-ui;
    background: #f4faff;
    margin: 0;
    padding: 20px;
}
.box{
    max-width: 600px;
    margin: auto;
    background: white;
    padding: 22px;
    border-radius: 12px;
    box-shadow: 0 6px 20px rgba(0,0,0,0.08);
}
h2{
    margin-top: 0;
    text-align:center;
}
.item{
    padding: 10px 0;
    border-bottom: 1px solid #eee;
}
.value{
    font-weight: 700;
}
.back-btn{
    display: block;
    text-align:center;
    margin-top: 20px;
    background: #2a9df4;
    color: white;
    padding: 10px 14px;
    border-radius: 8px;
    text-decoration: none;
    font-weight:700;
}
</style>
</head>

<body>

<div class="box">
    <h2>📈 Session Summary</h2>

    <div class="item">Session Started: <span class="value" id="ss-start">Loading...</span></div>
    <div class="item">Session End: <span class="value" id="ss-end">Loading...</span></div>
    <div class="item">Active Duration: <span class="value" id="ss-duration">0s</span></div>

    <div class="item">Passwords Revealed: <span class="value" id="ss-reveals">0</span></div>
    <div class="item">Vault Locks: <span class="value" id="ss-locks">0</span></div>
    <div class="item">Panic Triggered: <span class="value" id="ss-panic">No</span></div>

    <div class="item">Device: <span class="value" id="ss-device">Fetching...</span></div>

    <a class="back-btn" href="vault.php?user_id=<?php echo $user_id; ?>">⬅ Back to Vault</a>
</div>

<script>
// Read session data
const start_ts = Number(sessionStorage.getItem("session_start_ts") || Date.now());
const reveal_count = Number(sessionStorage.getItem("reveal_count") || 0);
const lock_count = Number(sessionStorage.getItem("lock_count") || 0);
const panic = sessionStorage.getItem("panic_mode") === "1";
const now = Date.now();

document.getElementById("ss-start").textContent = new Date(start_ts).toLocaleString();
document.getElementById("ss-end").textContent = new Date(now).toLocaleString();

// Duration
const diffSec = Math.round((now - start_ts) / 1000);
document.getElementById("ss-duration").textContent = diffSec + " seconds";

// Counters
document.getElementById("ss-reveals").textContent = reveal_count;
document.getElementById("ss-locks").textContent = lock_count;
document.getElementById("ss-panic").textContent = panic ? "YES (Triggered)" : "No";

// Device
document.getElementById("ss-device").textContent =
    navigator.platform + " — " + navigator.userAgent;
</script>

</body>
</html>
