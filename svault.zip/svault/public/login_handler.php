<?php
require_once __DIR__ . '/../src/config/db.php';
require_once __DIR__ . '/../src/bootstrap.php';

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if (!$username || !$password) die('missing');

$users = $db->users;
$user = $users->findOne(['username'=>$username]);
if (!$user) die('invalid user');
if (!password_verify($password, $user['password_hash'])) die('invalid credentials');

// create qr session token valid for 30 seconds
$token = bin2hex(random_bytes(16));
$expires = new MongoDB\BSON\UTCDateTime((time()+30)*1000);

$db->qr_sessions->insertOne([
    'token'=>$token,
    'user_id'=>$user['_id'],
    'password_id'=>null,
    'expires_at'=>$expires,
    'used'=>false,
    'verified_by_device'=>null
]);

// redirect to display QR (scannable PNG)
header('Location: generate_qr.php?token=' . $token);
