<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

require_once __DIR__ . '/../src/config/db.php';
require_once __DIR__ . '/../src/bootstrap.php';

// Read JSON
$data = json_decode(file_get_contents("php://input"), true);

$token = $data['token'] ?? null;
$device_id = $data['device_id'] ?? null;

if (!$token || !$device_id) {
    echo json_encode(["ok"=>false, "error"=>"Missing token or device_id"]);
    exit;
}

// Find QR session
$qr = $db->qr_sessions->findOne(["token" => $token]);

if (!$qr) {
    echo json_encode(["ok"=>false, "error"=>"Invalid or expired token"]);
    exit;
}

// Check expiration
$now = new DateTime();
$expiresAt = $qr["expires_at"]->toDateTime();

if ($now > $expiresAt) {
    echo json_encode(["ok"=>false, "error"=>"Token expired"]);
    exit;
}

// Find registered user’s device ID
$user = $db->users->findOne(["_id" => $qr["user_id"]]);

if (!$user) {
    echo json_encode(["ok"=>false, "error"=>"User not found"]);
    exit;
}

$registered_device = $user["device_id"];

if ($registered_device !== $device_id) {
    echo json_encode([
        "ok"=>false,
        "error"=>"Device mismatch",
        "expected"=>$registered_device,
        "got"=>$device_id
    ]);
    exit;
}

// Mark token as USED
$db->qr_sessions->updateOne(
    ["token" => $token],
    ['$set' => [
        "used" => true,
        "verified_by_device" => $device_id
    ]]
);

echo json_encode([
    "ok" => true,
    "message" => "QR Verified Successfully",
    "user_id" => (string)$qr["user_id"]
]);
