<?php
header('Content-Type: application/json');

require_once __DIR__ . '/../src/config/db.php';
require_once __DIR__ . '/../src/bootstrap.php';
require_once __DIR__ . '/../src/utils/qr.php';

$password_id = $_GET['password_id'] ?? null;
$user_id = $_GET['user_id'] ?? null;

if (!$password_id || !$user_id) {
    echo json_encode(['ok'=>false,'error'=>'Missing params']);
    exit;
}

$token = bin2hex(random_bytes(16));
$expires = new MongoDB\BSON\UTCDateTime((time()+30)*1000);

$db->qr_sessions->insertOne([
    'token'=>$token,
    'user_id'=>new MongoDB\BSON\ObjectId($user_id),
    'password_id'=>new MongoDB\BSON\ObjectId($password_id),
    'expires_at'=>$expires,
    'used'=>false,
    'verified_by_device'=>null
]);

// 🔥 THIS IS THE FIX — QR contains ONLY the token
$payload = $token;

// Build QR Image (PNG base64)
$qrImage = build_qr_dataurl($payload);

echo json_encode([
    'ok'=>true,
    'token'=>$token,
    'qr'=>$qrImage,
    'expires'=>$expires->toDateTime()->format(DATE_ATOM)
]);
