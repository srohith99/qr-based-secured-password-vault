<?php
require_once __DIR__ . '/../src/bootstrap.php';
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Register — Secured Vault</title>

<style>
/* GOOGLE FONT */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800&display=swap');

*{
  margin:0; padding:0; box-sizing:border-box;
  font-family:"Poppins",sans-serif;
}

body{
  height:100vh;
  overflow:hidden;
  background:#02050a;
  color:white;
}

/* ░░░░ ULTRA NEON ANIMATED GRADIENT ░░░░ */
.bg-gradient{
  position:fixed;
  top:0; left:0;
  width:200%; height:200%;
  background:linear-gradient(130deg,#000a16,#001b30,#003d74,#006cda,#00f6ff);
  background-size:400% 400%;
  animation:gradientFlow 16s ease-in-out infinite;
  filter:blur(160px);
  z-index:-3;
}
@keyframes gradientFlow{
  0%{background-position:0% 50%;}
  50%{background-position:100% 50%;}
  100%{background-position:0% 50%;}
}

/* ░░░░ CYBER GRID OVERLAY ░░░░ */
.grid-overlay{
  position:fixed;
  inset:0;
  background-image:
    linear-gradient(rgba(255,255,255,0.04) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255,255,255,0.04) 1px, transparent 1px);
  background-size:46px 46px;
  z-index:-2;
}

/* PARTICLES */
#particles{
  position:fixed;
  inset:0;
  z-index:-1;
}

/* MAIN WRAPPER */
.register-wrapper{
  height:100vh;
  display:flex;
  align-items:center;
  justify-content:center;
  padding:20px;
}

/* GLASS FORM CARD */
.register-card{
  width:420px;
  padding:30px;
  border-radius:20px;
  background:rgba(255,255,255,0.12);
  backdrop-filter:blur(18px);
  border:1px solid rgba(0,255,255,0.25);
  box-shadow:0 4px 40px rgba(0,200,255,0.25);
  animation:float 7s ease-in-out infinite;
}

@keyframes float{
  0%{transform:translateY(0);}
  50%{transform:translateY(-12px);}
  100%{transform:translateY(0);}
}

.title{
  font-size:26px;
  font-weight:800;
  text-align:center;
  color:#00eaff;
  margin-bottom:6px;
}

.subtitle{
  text-align:center;
  font-size:14px;
  color:#c8f3ff;
  margin-bottom:20px;
}

form label{
  display:block;
  font-weight:600;
  margin-top:16px;
}

form input{
  width:100%;
  padding:12px;
  background:rgba(255,255,255,0.12);
  border:1px solid rgba(255,255,255,0.22);
  border-radius:8px;
  margin-top:6px;
  font-size:15px;
  color:white;
  outline:none;
}

form input:focus{
  border-color:#00eaff;
  box-shadow:0 0 12px #00d5ff99;
}

/* BUTTON */
.btn-register{
  width:100%;
  padding:14px;
  border:none;
  border-radius:10px;
  margin-top:22px;
  background:linear-gradient(115deg,#00d5ff,#0078ff);
  color:white;
  font-weight:700;
  font-size:15px;
  cursor:pointer;
  transition:0.25s ease;
}

.btn-register:hover{
  transform:scale(1.05);
  box-shadow:0 0 18px #00eaffaa;
}

.note{
  margin-top:16px;
  text-align:center;
  font-size:13px;
  color:#d8f3ff;
  opacity:0.85;
}
</style>

</head>

<body>

<!-- BACKGROUND -->
<div class="bg-gradient"></div>
<div class="grid-overlay"></div>
<canvas id="particles"></canvas>

<!-- REGISTER CARD -->
<div class="register-wrapper">
  <section class="register-card">

    <h1 class="title">🔐 Create Account</h1>
    <p class="subtitle">Secure Registration with Device Binding</p>

    <form method="POST" action="register_handler.php">

      <label>Username</label>
      <input name="username" required>

      <label>Master Password</label>
      <input type="password" name="password" required>

      <label>Device ID (Store this in your mobile)</label>
      <input name="device_id" required>

      <button class="btn-register">Register</button>

    </form>

    <p class="note">This binds your account to your mobile device for QR-based MFA.</p>

  </section>
</div>

<!-- PARTICLES SCRIPT -->
<script>
const canvas = document.getElementById("particles");
const ctx = canvas.getContext("2d");

let w, h;
function resize(){
  w = canvas.width = window.innerWidth;
  h = canvas.height = window.innerHeight;
}
resize();
window.onresize = resize;

let particles = [];
for(let i=0;i<80;i++){
  particles.push({
    x: Math.random()*w,
    y: Math.random()*h,
    r: Math.random()*2 + 1,
    dx: (Math.random() - 0.5) * 0.6,
    dy: (Math.random() - 0.5) * 0.6,
  });
}

function draw(){
  ctx.clearRect(0,0,w,h);

  particles.forEach(p=>{
    ctx.beginPath();
    ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
    ctx.fillStyle = "#00eaff";
    ctx.fill();

    p.x += p.dx;
    p.y += p.dy;

    if(p.x < 0 || p.x > w) p.dx *= -1;
    if(p.y < 0 || p.y > h) p.dy *= -1;
  });

  requestAnimationFrame(draw);
}
draw();
</script>

</body>
</html>
