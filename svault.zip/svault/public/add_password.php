<?php
require_once __DIR__ . '/../src/bootstrap.php';
$user_id = $_GET['user_id'] ?? '';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Add Password — Secured Vault</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
/* ======================== ROOT COLORS ========================= */
:root{
  --bg1: #d9f1ff;
  --bg2: #ffffff;
  --bg3: #b7e2ff;
  --accent: #00b4ff;
  --accent2: #2a9df4;
  --card: rgba(255,255,255,0.55);
  --glass: rgba(255,255,255,0.45);
  --muted: #5a7184;
}

/* ======================== ANIMATED GRADIENT BG ========================= */
html,body{
  height:100%;
  margin:0;
  font-family: 'Inter', system-ui, sans-serif;
  background: linear-gradient(135deg, var(--bg1), var(--bg2), var(--bg3));
  background-size: 320% 320%;
  animation: bgMove 12s ease infinite;
}

@keyframes bgMove {
  0%   { background-position: 0% 50%; }
  50%  { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

/* ======================== CENTERING ========================= */
.container{
  max-width: 420px;
  margin: 60px auto;
  padding: 20px;
}

/* ======================== CARD ========================= */
.card{
  background: var(--glass);
  padding: 26px;
  border-radius: 18px;
  box-shadow: 0 12px 40px rgba(0,0,0,0.12);
  backdrop-filter: blur(14px);
  animation: fadeIn 0.8s ease;
}

@keyframes fadeIn {
  from { opacity:0; transform: translateY(20px); }
  to   { opacity:1; transform: translateY(0); }
}

.card h2{
  margin:0 0 18px;
  font-size: 1.6rem;
  font-weight: 800;
  color:#00344f;
  text-align:center;
}

/* ======================== INPUTS ========================= */
label{
  display:block;
  font-weight:700;
  margin-top:14px;
  font-size:14px;
  color:#00364e;
}

input{
  width:100%;
  padding:12px;
  margin-top:6px;
  font-size:15px;
  border-radius:10px;
  border:1px solid #bde9ff;
  background:#f7fcff;
  outline:none;
  transition:0.2s;
}

input:focus{
  border-color:#009dff;
  box-shadow:0 0 0 3px rgba(0,150,255,0.15);
}

/* ======================== BUTTON ========================= */
.btn{
  width:100%;
  padding:12px;
  margin-top:20px;
  background:linear-gradient(90deg, var(--accent), var(--accent2));
  border:none;
  border-radius:12px;
  color:white;
  font-size:16px;
  font-weight:700;
  cursor:pointer;
  box-shadow:0 8px 25px rgba(0,150,255,0.25);
  transition:0.2s;
}

.btn:hover{
  transform: translateY(-3px);
  box-shadow:0 12px 35px rgba(0,150,255,0.35);
}

.btn:active{
  transform:scale(0.97);
}

/* ======================== DARK MODE ========================= */
.dark{
  background: linear-gradient(135deg,#06121c,#0a1c2c);
}

.dark .card{
  background: rgba(0,0,0,0.35);
  color:white;
}

.dark label{ color:#d9f4ff; }
.dark input{
  background:#0f2538;
  border:1px solid #1e4963;
  color:#e7f9ff;
}
.dark .btn{
  box-shadow:none;
}

.toggle-dark{
  position:fixed;
  right:20px;
  top:20px;
  background:rgba(255,255,255,0.5);
  border:0;
  padding:10px 14px;
  font-size:18px;
  border-radius:50%;
  cursor:pointer;
  backdrop-filter:blur(10px);
}
.back-btn{
  display:inline-block;
  margin-bottom:16px;
  padding:10px 16px;
  border-radius:10px;
  background:rgba(255,255,255,0.5);
  backdrop-filter:blur(10px);
  color:#004b6a;
  font-weight:700;
  text-decoration:none;
  box-shadow:0 6px 20px rgba(0,0,0,0.08);
  transition:0.22s ease;
}

.back-btn:hover{
  transform:translateY(-3px);
  background:rgba(255,255,255,0.75);
  box-shadow:0 10px 28px rgba(0,0,0,0.12);
}

.dark .back-btn{
  background:rgba(255,255,255,0.15);
  color:#d6f4ff;
}

.dark .back-btn:hover{
  background:rgba(255,255,255,0.25);
}

</style>
</head>

<body>

<button class="toggle-dark" onclick="toggleDark()">🌙</button>

<main class="container">
  <section class="card">
    <h2>➕ Add Password Entry</h2>
    <a href="vault.php?user_id=<?php echo urlencode($user_id); ?>" class="back-btn">← Back to Vault</a>

    <form method="POST" action="save_password.php">
      <label>Site Name
        <input name="site_name" required>
      </label>

      <label>Site URL
        <input name="site_url">
      </label>

      <label>Password
        <input name="password" required>
      </label>

      <input type="hidden" name="user_id" value="<?php echo htmlentities($user_id); ?>">

      <button class="btn">Save Password</button>
    </form>
  </section>
</main>

<script>
function toggleDark(){
  document.body.classList.toggle("dark");
}
</script>

</body>
</html>
