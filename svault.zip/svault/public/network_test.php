<?php
header("Content-Type: application/json");

$response = [];

// Client IP
$response["client_ip"] = $_SERVER["REMOTE_ADDR"] ?? "unknown";

// Request method
$response["method"] = $_SERVER["REQUEST_METHOD"];

// Raw POST body
$raw = file_get_contents("php://input");
$response["raw_body"] = $raw;

// JSON decode (if sent)
if ($raw) {
    $response["json_decoded"] = json_decode($raw, true);
} else {
    $response["json_decoded"] = null;
}

// Server info
$response["server_ip"] = $_SERVER["SERVER_ADDR"] ?? "unknown";
$response["server_port"] = $_SERVER["SERVER_PORT"] ?? "unknown";

// Timestamp
$response["time"] = date("Y-m-d H:i:s");

// Success message
$response["message"] = "Network test reached successfully! Your mobile CAN reach the server.";

echo json_encode($response, JSON_PRETTY_PRINT);
