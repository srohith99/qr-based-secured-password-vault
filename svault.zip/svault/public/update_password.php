<?php
require_once __DIR__ . '/../src/config/db.php';
require_once __DIR__ . '/../src/bootstrap.php';
require_once __DIR__ . '/../src/utils/crypto.php';

$user_id = $_GET['user_id'] ?? null;
$password_id = $_GET['password_id'] ?? null;

if (!$user_id || !$password_id) { 
    echo 'Missing parameters — authenticate via QR'; 
    exit; 
}

try {
    $uid = new MongoDB\BSON\ObjectId($user_id);
    $pid = new MongoDB\BSON\ObjectId($password_id);
} catch (Exception $e) { 
    echo 'Invalid ID'; 
    exit; 
}

// Updated crypto functions - binary key and IV || CT HMAC order
if (!function_exists('crypto_encrypt')) {
    function crypto_encrypt($plaintext, $key) {
        $method = 'AES-256-CBC';
        $iv_length = openssl_cipher_iv_length($method);
        $iv = openssl_random_pseudo_bytes($iv_length);
        $encrypted = openssl_encrypt($plaintext, $method, $key, 0, $iv);
        if ($encrypted === false) {
            error_log("Encrypt failed: " . openssl_error_string());
            return false;
        }
        $ct = base64_encode($encrypted);
        $iv_b64 = base64_encode($iv);
        // Standard order: IV || CT for HMAC
        $hmac = base64_encode(hash_hmac('sha256', $iv_b64 . $ct, $key, true));
        return json_encode([
            'iv' => $iv_b64,
            'ct' => $ct,
            'hmac' => $hmac
        ]);
    }
}
function crypto_decrypt($payload_json, $key) {

    // NEW FORMAT? (JSON with iv, ct)
    if (strpos($payload_json, '{') === 0) {
        $data = json_decode($payload_json, true);
        if (!$data || !isset($data['iv']) || !isset($data['ct'])) {
            return false;
        }

        // Validate HMAC
        $expected_hmac = base64_encode(hash_hmac('sha256', $data['iv'] . $data['ct'], $key, true));
        if (!hash_equals($expected_hmac, $data['hmac'])) {
            return false; // tampering or wrong key
        }

        $iv = base64_decode($data['iv']);
        $ct = base64_decode($data['ct']);

        return openssl_decrypt($ct, "AES-256-CBC", $key, 0, $iv);
    }

    // OLD FORMAT fallback (before update)
    $cipher = base64_decode($payload_json);
    if ($cipher === false) return false;

    // OLD FORMAT used static IV or embedded IV?  
    // If old format used fixed IV:
    $old_iv = substr(hash('sha256', 'legacy_iv'), 0, 16);

    return openssl_decrypt($cipher, "AES-256-CBC", $key, OPENSSL_RAW_DATA, $old_iv);
}


// Placeholder for getUserKey - BINARY key (32 bytes)
function getUserKey($uid) {
    return hash('sha256', (string)$uid . '_master_key_salt', true); // Binary!
}

// Handle POST update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $site_name = trim($_POST['site_name'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $site_url = trim($_POST['site_url'] ?? '');

    if (empty($site_name) || empty($password)) {
        $error = 'Site name and password are required.';
    } else {
        $user_key = getUserKey($uid);
        $encrypted_payload = crypto_encrypt($password, $user_key);

        if ($encrypted_payload === false) {
            $error = 'Encryption failed - contact support.';
        } else {
            $update_result = $db->passwords->updateOne(
                ['_id' => $pid, 'user_id' => $uid],
                ['$set' => [
                    'site_name' => $site_name,
                    'site_url' => $site_url ?: 'https://example.com',
                    'encrypted_payload' => $encrypted_payload,
                    'updated_at' => new MongoDB\BSON\UTCDateTime()
                ]]
            );

            if ($update_result->getModifiedCount() === 1) {
                // Log the update to audit
                $db->audit_logs->insertOne([
                    'user_id' => $uid,
                    'event_type' => 'password_update',
                    'event_data' => [
                        'password_id' => (string)$pid,
                        'site_name' => $site_name,
                        'site_url' => $site_url,
                        'updated_at' => new MongoDB\BSON\UTCDateTime()
                    ],
                    'timestamp' => new MongoDB\BSON\UTCDateTime()
                ]);

                // Optional debug: Log the new encrypted value (remove in prod)
                error_log("Updated payload for ID $password_id: " . substr($encrypted_payload, 0, 50) . "...");

                header("Location: vault.php?user_id=" . urlencode($user_id) . "&updated=1");
                exit;
            } else {
                $error = 'Update failed. Password not found or unauthorized.';
            }
        }
    }
}

// Fetch current password for prefill
$current = $db->passwords->findOne(['_id' => $pid, 'user_id' => $uid]);
if (!$current) { 
    echo 'Password not found'; 
    exit; 
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Update Password - Secured Vault</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
  /* --------- Colors & layout --------- */
  :root{
    --bg1: #e6f9ff;
    --bg2: #ffffff;
    --accent: #00b4ff;
    --accent-2: #2a9df4;
    --muted: #6b7280;
    --card: #ffffff;
    --glass: rgba(255,255,255,0.75);
    --danger: #e02b2b;
    --success: #10b981;
  }
  *{box-sizing:border-box}
  html,body{height:100%;margin:0;font-family:Inter,system-ui,Segoe UI,Roboto,Arial;background:linear-gradient(135deg,var(--bg1),var(--bg2));background-size:300% 300%;animation:bgFlow 12s linear infinite;color:#072033;}
  @keyframes bgFlow{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}

  /* Topbar */
  .topbar{display:flex;justify-content:space-between;align-items:center;padding:14px 22px;background:rgba(255,255,255,0.9);backdrop-filter:blur(6px);box-shadow:0 6px 20px rgba(8,18,28,0.05);position:sticky;top:0;z-index:30;}
  .topbar .title{font-weight:700;font-size:1.2rem}
  .topbar .controls{display:flex;gap:10px;align-items:center}

  /* Main layout */
  .container{max-width:1200px;margin:22px auto;padding:18px;display:grid;grid-template-columns:260px 1fr;gap:20px}
  @media (max-width:920px){ .container{grid-template-columns:1fr} }

  /* Sidebar */
  .sidebar{background:var(--card);padding:16px;border-radius:12px;box-shadow:0 10px 30px rgba(2,6,12,0.06)}
  .nav{display:block;padding:10px;border-radius:10px;color:var(--accent);text-decoration:none;font-weight:600;margin-bottom:8px}
  .nav:hover{background:#eef9ff}

  /* Update form */
  .update-section{max-width:500px;margin:0 auto}
  .form-card{background:var(--card);padding:24px;border-radius:12px;box-shadow:0 8px 24px rgba(8,18,28,0.06)}
  .form-group{margin-bottom:18px}
  .form-group label{display:block;margin-bottom:6px;font-weight:600;color:var(--muted)}
  .form-group input[type="text"], .form-group input[type="password"], .form-group input[type="url"]{width:100%;padding:12px;border:1px solid #e5e7eb;border-radius:8px;font-size:1rem;transition:border-color .2s}
  .form-group input:focus{outline:none;border-color:var(--accent)}
  .error{color:var(--danger);background:#fee2e2;padding:12px;border-radius:8px;margin-bottom:18px}
  .success{color:var(--success);background:#ecfdf5;padding:12px;border-radius:8px;margin-bottom:18px}

  /* small UI niceties */
  .btn { background:linear-gradient(90deg,var(--accent),var(--accent-2)); color:white; padding:12px 20px; border-radius:8px; border:0; font-weight:700; cursor:pointer; text-decoration:none; display:inline-block; text-align:center; margin-right:10px; }
  .btn.small{padding:6px 8px;font-size:.9rem}
  .btn.danger { background: var(--danger); }
  .btn.success { background: var(--success); color: white; }

  /* dark mode */
  .dark body, .dark{ background: linear-gradient(145deg,#071322,#081827);}
  .dark .card, .dark .form-card{ background: rgba(6,24,38,0.85); color:#dff6ff }
  .dark .sidebar { background: rgba(6,24,38,0.85) }
  .dark .form-group input{ background: rgba(255,255,255,0.1); border-color: rgba(255,255,255,0.2); color:#dff6ff }
</style>
</head>
<body>

<header class="topbar">
  <div class="title">🔐 Secured Vault - Update</div>
  <div class="controls">
    <button id="themeToggle" class="btn small">Toggle Dark</button>
    <a href="lock_vault.php?user_id=<?php echo urlencode($user_id); ?>" class="btn small">Lock</a>
    <a href="vault.php?user_id=<?php echo urlencode($user_id); ?>" class="btn small">Back to Vault</a>
  </div>
</header>

<main class="container">
  <aside class="sidebar">
    <a class="nav" href="add_password.php?user_id=<?php echo $user_id; ?>">➕ Add password</a>
    <a class="nav" href="vault.php?user_id=<?php echo $user_id; ?>">🏠 Vault</a>
    <a class="nav" href="deleted_passwords.php?user_id=<?php echo $user_id; ?>">🗑️ Recently Deleted</a>
    <a class="nav" href="security_logs.php?user_id=<?php echo $user_id; ?>">📊 Security logs</a>
    <p style="margin-top:12px;color:var(--muted);font-weight:600;">Last login: <?php echo date('Y-m-d H:i'); ?></p>
  </aside>

  <section class="update-section">
    <form method="POST">

  <div class="form-group">
    <label for="site_name">Site Name / Email</label>
    <input type="text" id="site_name" name="site_name"
      value="<?php echo htmlentities($current['site_name'] ?? ''); ?>" required>
  </div>

  <div class="form-group">
    <label for="site_url">Site URL (optional)</label>
    <input type="url" id="site_url" name="site_url"
      value="<?php echo htmlentities($current['site_url'] ?? ''); ?>"
      placeholder="https://example.com">
  </div>

  <div class="form-group">
    <label for="old_password">Old Password (required for update)</label>
    <input type="password" id="old_password" name="old_password"
      placeholder="Enter old password" required minlength="6">
  </div>

  <div class="form-group">
    <label for="password">New Password</label>
    <input type="password" id="password" name="password"
      placeholder="Enter new password" required minlength="6">
  </div>

  <div style="margin-top:20px;">
    <button type="submit" class="btn">Update Password</button>
    <a href="vault.php?user_id=<?php echo urlencode($user_id); ?>" class="btn danger small">Cancel</a>
  </div>

</form>

    </div>
  </section>
</main>

<script>
// Simple theme toggle (assuming similar to vault.js)
document.getElementById('themeToggle').addEventListener('click', () => {
  document.body.classList.toggle('dark');
  localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
});
</script>

</body>
</html>