<?php
require_once __DIR__ . '/../src/config/db.php';
require_once __DIR__ . '/../src/bootstrap.php';

$user_id = $_GET['user_id'] ?? '';
if (!$user_id) { die("Missing user_id"); }

try {
    $uid = new MongoDB\BSON\ObjectId($user_id);
} catch (Exception $e) {
    die("Invalid user ID");
}

// Fetch logs
$audit = $db->audit_logs->find(
    ['user_id' => $uid],
    ['sort' => ['_id' => -1]]
)->toArray();

$detections = $db->detection_logs->find(
    ['user_id' => $uid],
    ['sort' => ['_id' => -1]]
)->toArray();

// Fetch password-specific operations logs
$password_logs = $db->audit_logs->find(
    ['user_id' => $uid, 'event_type' => ['$in' => ['password_update', 'password_delete']]],
    ['sort' => ['_id' => -1]]
)->toArray();

date_default_timezone_set("Asia/Kolkata");
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Security Logs</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            --bg-secondary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --card-bg: rgba(255, 255, 255, 0.85);
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --border-color: #e2e8f0;
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --accent: #3b82f6;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
        }

        [data-theme="dark"] {
            --bg-primary: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            --bg-secondary: linear-gradient(135deg, #1e40af 0%, #3730a3 100%);
            --card-bg: rgba(30, 41, 59, 0.85);
            --text-primary: #f1f5f9;
            --text-secondary: #94a3b8;
            --border-color: #334155;
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.2), 0 2px 4px -1px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.3), 0 4px 6px -2px rgba(0, 0, 0, 0.2);
            --accent: #60a5fa;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1.5rem 2rem;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid var(--border-color);
        }

        .header h1 {
            font-size: 1.75rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            background: var(--card-bg);
            color: var(--text-primary);
            text-decoration: none;
            border-radius: 0.75rem;
            font-weight: 500;
            transition: all 0.2s ease;
            border: 1px solid var(--border-color);
            box-shadow: var(--shadow);
        }

        .back-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
            background: rgba(255, 255, 255, 0.95);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }

        .logs-card {
            background: var(--card-bg);
            backdrop-filter: blur(14px);
            border-radius: 1rem;
            box-shadow: var(--shadow-lg);
            overflow: hidden;
            border: 1px solid var(--border-color);
        }

        .tabs {
            display: flex;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid var(--border-color);
        }

        .tab-btn {
            flex: 1;
            padding: 1rem;
            background: none;
            border: none;
            font-size: 0.95rem;
            font-weight: 500;
            color: var(--text-secondary);
            cursor: pointer;
            transition: all 0.2s ease;
            border-bottom: 2px solid transparent;
        }

        .tab-btn.active {
            color: var(--accent);
            border-bottom-color: var(--accent);
            background: rgba(59, 130, 246, 0.1);
        }

        .tab-btn:hover {
            color: var(--text-primary);
            background: rgba(0, 0, 0, 0.05);
        }

        .tab-content {
            display: none;
            padding: 2rem;
        }

        .tab-content.active {
            display: block;
        }

        .section-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .table-container {
            overflow-x: auto;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 0.5rem;
            overflow: hidden;
        }

        [data-theme="dark"] table {
            background: var(--card-bg);
        }

        th {
            background: var(--bg-secondary);
            color: white;
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        td {
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
            font-size: 0.875rem;
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr:hover {
            background: rgba(59, 130, 246, 0.05);
        }

        .event-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .event-update { background: rgba(16, 185, 129, 0.1); color: var(--success); }
        .event-delete { background: rgba(239, 68, 68, 0.1); color: var(--danger); }
        .event-other { background: rgba(245, 158, 11, 0.1); color: var(--warning); }

        .no-logs {
            text-align: center;
            padding: 3rem;
            color: var(--text-secondary);
            font-style: italic;
        }

        .theme-toggle {
            position: fixed;
            top: 1rem;
            right: 1rem;
            padding: 0.75rem 1rem;
            background: var(--accent);
            color: white;
            border: none;
            border-radius: 0.5rem;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.2s ease;
            box-shadow: var(--shadow);
            z-index: 1000;
        }

        .theme-toggle:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        @media (max-width: 768px) {
            .header {
                padding: 1rem;
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }

            .container {
                padding: 1rem;
            }

            .tab-content {
                padding: 1rem;
            }

            .tabs {
                flex-direction: column;
            }

            table {
                font-size: 0.75rem;
            }

            th, td {
                padding: 0.75rem 0.5rem;
            }
        }

        .details-json {
            background: rgba(0, 0, 0, 0.05);
            padding: 0.5rem;
            border-radius: 0.25rem;
            font-family: monospace;
            font-size: 0.8rem;
            word-break: break-all;
        }

        [data-theme="dark"] .details-json {
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-primary);
        }
    </style>
</head>
<body data-theme="light">

    <button class="theme-toggle" id="themeToggle">🌙 Dark Mode</button>

    <header class="header">
        <h1>🔐 Security Logs</h1>
        <a href="vault.php?user_id=<?php echo urlencode($user_id); ?>" class="back-btn">← Back to Vault</a>
    </header>

    <div class="container">
        <div class="logs-card">
            <div class="tabs">
                <button class="tab-btn active" data-tab="audit">Audit Logs</button>
                <button class="tab-btn" data-tab="password">Password Operations</button>
                <button class="tab-btn" data-tab="detections">AI Threat Detections</button>
            </div>

            <div class="tab-content active" id="audit">
                <h2 class="section-title">📋 Recent Audit Events</h2>
                <?php if (empty($audit)): ?>
                    <div class="no-logs">No audit logs found.</div>
                <?php else: ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Time (IST)</th>
                                    <th>Event</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($audit as $log): ?>
                                    <tr>
                                        <td><?php echo date('Y-m-d H:i:s', $log['_id']->getTimestamp()); ?></td>
                                        <td><?php echo htmlentities($log['event_type']); ?></td>
                                        <td>
                                            <div class="details-json"><?php echo htmlentities(json_encode($log['event_data'] ?? [], JSON_PRETTY_PRINT)); ?></div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <div class="tab-content" id="password">
                <h2 class="section-title">🔑 Password Actions</h2>
                <?php if (empty($password_logs)): ?>
                    <div class="no-logs">No password operations found.</div>
                <?php else: ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Time (IST)</th>
                                    <th>Action</th>
                                    <th>Site</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($password_logs as $log): ?>
                                    <tr>
                                        <td><?php echo date('Y-m-d H:i:s', $log['_id']->getTimestamp()); ?></td>
                                        <td>
                                            <span class="event-badge event-<?php echo str_replace('password_', '', $log['event_type']); ?>">
                                                <?php echo htmlentities(ucfirst(str_replace('password_', '', $log['event_type']))); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlentities($log['event_data']['site_name'] ?? 'N/A'); ?></td>
                                        <td>
                                            <div class="details-json"><?php echo htmlentities(json_encode($log['event_data'] ?? [], JSON_PRETTY_PRINT)); ?></div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <div class="tab-content" id="detections">
                <h2 class="section-title">🤖 AI Threat Detections</h2>
                <?php if (empty($detections)): ?>
                    <div class="no-logs">No detection logs found.</div>
                <?php else: ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Time (IST)</th>
                                    <th>Detected Threats</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($detections as $d): ?>
                                    <tr>
                                        <td><?php echo date('Y-m-d H:i:s', $d['_id']->getTimestamp()); ?></td>
                                        <td>
                                            <div class="details-json"><?php echo htmlentities(json_encode($d['predictions'] ?? [], JSON_PRETTY_PRINT)); ?></div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // Tab switching
        const tabBtns = document.querySelectorAll('.tab-btn');
        const tabContents = document.querySelectorAll('.tab-content');

        tabBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const targetTab = btn.dataset.tab;

                tabBtns.forEach(b => b.classList.remove('active'));
                tabContents.forEach(c => c.classList.remove('active'));

                btn.classList.add('active');
                document.getElementById(targetTab).classList.add('active');
            });
        });

        // Theme toggle
        const themeToggle = document.getElementById('themeToggle');
        const body = document.body;

        themeToggle.addEventListener('click', () => {
            const currentTheme = body.getAttribute('data-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            body.setAttribute('data-theme', newTheme);
            themeToggle.textContent = newTheme === 'dark' ? '☀️ Light Mode' : '🌙 Dark Mode';
        });
    </script>

</body>
</html>