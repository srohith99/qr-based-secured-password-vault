<?php
require_once __DIR__ . '/../src/bootstrap.php';
$user_id = $_GET['user_id'] ?? '';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Password Strength Analyzer</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
/* ================================
   CYBER DARK HACKER THEME UI
   ================================ */

:root{
  --bg: #05070d;
  --bg2: #0c111a;
  --card: #0f1622;
  --border: #1a2333;
  --neon: #0ff;
  --neon2: #00b7ff;
  --text: #d3e9ff;
  --text-muted: #6b8aaa;
  --glow: 0 0 10px #0ff, 0 0 25px #00b7ff55;
}

body {
  margin: 0;
  font-family: Inter, sans-serif;
  background: radial-gradient(circle at top, #0a0f18, #02040a 70%);
  color: var(--text);
}

/* Top bar */
.topbar {
  display:flex;
  justify-content:space-between;
  align-items:center;
  padding:18px 26px;
  background:#060b12;
  border-bottom:1px solid var(--neon2);
  box-shadow:0 0 12px #00b7ff44;
}

.title {
  font-size:1.3rem;
  font-weight:800;
  color:var(--neon);
  text-shadow:var(--glow);
}

.btn {
  background:transparent;
  border:1px solid var(--neon2);
  color:var(--neon);
  padding:8px 14px;
  border-radius:6px;
  font-weight:700;
  cursor:pointer;
  transition:0.2s;
  text-decoration:none;
}

.btn:hover {
  background:var(--neon2);
  color:black;
  box-shadow:var(--glow);
}

/* Container */
.main {
  max-width:900px;
  margin:40px auto;
  background:#0b121d;
  border:1px solid var(--border);
  padding:24px;
  border-radius:12px;
  box-shadow:0 0 18px #00b7ff33;
}

/* Analyzer input */
.pw-input {
  width:100%;
  padding:12px 14px;
  background:#050b13;
  border:1px solid var(--border);
  border-radius:8px;
  font-size:1.1rem;
  color:var(--text);
  font-family:monospace;
  letter-spacing:1px;
}

.pw-input:focus {
  outline:none;
  border-color:var(--neon2);
  box-shadow:var(--glow);
}

/* Meter */
.meter {
  width:100%;
  height:14px;
  border-radius:8px;
  background:#071018;
  overflow:hidden;
  margin-top:16px;
  box-shadow:inset 0 0 8px #000;
}
.meter > i {
  display:block;
  height:100%;
  width:0%;
  transition:width .35s ease;
}

/* Info */
.entropy-box {
  display:flex;
  margin-top:10px;
  align-items:center;
  gap:12px;
}

.entropy-pill {
  padding:6px 12px;
  border-radius:10px;
  background:#00121a;
  border:1px solid var(--neon2);
  color:var(--neon);
  font-weight:700;
}

.score-text {
  font-weight:700;
  font-size:1rem;
  color:var(--text);
}

.meta {
  margin-top:16px;
  font-size:0.95rem;
  color:var(--text-muted);
}

ul.suggestions {
  margin-top:16px;
  padding-left:20px;
  line-height:1.5;
}
.suggestions li {
  margin-bottom:6px;
  color:#b6e6ff;
}
</style>
</head>
<body>

<header class="topbar">
  <div class="title">🔍 Password Strength Analyzer</div>
  <a href="vault.php?user_id=<?php echo urlencode($user_id); ?>" class="btn">← Back to Vault</a></header>

<main class="main">

  <label>Password Input (analyzes live):</label>
  <input type="password" id="pw" class="pw-input" placeholder="Type password..." autofocus>

  <div class="meter"><i id="meter-fill"></i></div>

  <div class="entropy-box">
    <div class="entropy-pill" id="entropy-bits">0 bits</div>
    <div class="score-text" id="score-text">Score: —</div>
  </div>

  <div class="meta">
    <div id="crack-time">Estimated crack time: —</div>
    <div class="small" style="margin-top:4px;">Assuming attacker can make 10 billion guesses/sec</div>
  </div>

  <ul class="suggestions" id="suggestions"></ul>

</main>


<script>
/* Password Analyzer Script */
(function(){
  const pw = document.getElementById("pw");
  const meter = document.getElementById("meter-fill");
  const entropyEl = document.getElementById("entropy-bits");
  const scoreEl = document.getElementById("score-text");
  const crackEl = document.getElementById("crack-time");
  const suggEl = document.getElementById("suggestions");

  const GPS = 1e10; // guesses per second

  function log2(x){ return Math.log(x)/Math.log(2); }

  function poolSize(p){
    let s=0;
    if(/[a-z]/.test(p)) s+=26;
    if(/[A-Z]/.test(p)) s+=26;
    if(/[0-9]/.test(p)) s+=10;
    if(/[^A-Za-z0-9]/.test(p)) s+=33;
    return s || 1;
  }

  function entropy(p){
    const ps = poolSize(p);
    return p.length * log2(ps);
  }

  function score(ent){
    return Math.min(100, Math.round((ent / 80) * 100));
  }

  function crackTime(ent){
    const guesses = Math.pow(2, ent) / 2;
    const sec = guesses / GPS;
    if(sec < 0.001) return "Instant";
    if(sec < 1) return (sec*1000).toFixed(0)+" ms";
    if(sec < 60) return sec.toFixed(1)+" s";
    if(sec < 3600) return (sec/60).toFixed(1)+" min";
    if(sec < 86400) return (sec/3600).toFixed(1)+" hours";
    if(sec < 31556926) return (sec/86400).toFixed(1)+" days";
    if(sec < 1e10) return (sec/31556926).toFixed(1)+" years";
    return (sec/31556926).toExponential(2)+" years";
  }

  function suggestions(p){
    const s=[];
    if(p.length < 8) s.push("Use 8+ characters (12+ recommended).");
    if(!/[A-Z]/.test(p)) s.push("Add uppercase letters (A–Z).");
    if(!/[a-z]/.test(p)) s.push("Add lowercase letters (a–z).");
    if(!/[0-9]/.test(p)) s.push("Include digits (0–9).");
    if(!/[^A-Za-z0-9]/.test(p)) s.push("Add special symbols (!@#$…).");
    if(/password|123456|qwerty|admin/i.test(p))
      s.push("Avoid predictable patterns and common passwords.");
    return s;
  }

  pw.addEventListener("input", ()=>{
    const p = pw.value;
    const ent = entropy(p);
    const scr = score(ent);

    entropyEl.textContent = Math.round(ent)+" bits";
    scoreEl.textContent = "Score: "+scr+"/100";

    // meter fill
    meter.style.width = scr+"%";
    if(scr < 40) meter.style.background = "linear-gradient(90deg,#ff3355,#ff0040)";
    else if(scr < 70) meter.style.background = "linear-gradient(90deg,#ffbb33,#ff8844)";
    else meter.style.background = "linear-gradient(90deg,#00ff99,#00b7ff)";

    crackEl.textContent = "Estimated crack time: "+crackTime(ent);

    const sug = suggestions(p);
    suggEl.innerHTML = sug.map(i=>"<li>"+i+"</li>").join("");
  });
})();
</script>

</body>
</html>
