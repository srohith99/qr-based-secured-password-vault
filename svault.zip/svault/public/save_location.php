<?php
header("Content-Type: application/json");

require_once __DIR__ . '/../src/config/db.php';

$raw = file_get_contents("php://input");
if (!$raw) {
    echo json_encode(["ok"=>false, "error"=>"no_input"]);
    exit;
}
$data = json_decode($raw, true);

if (!$data || !isset($data["user_id"])) {
    echo json_encode(["ok"=>false, "error"=>"invalid_data"]);
    exit;
}

try {
    $uid = new MongoDB\BSON\ObjectId($data["user_id"]);
} catch (Exception $e) {
    echo json_encode(["ok"=>false, "error"=>"invalid_user_id"]);
    exit;
}

$doc = [
    "user_id" => $uid,
    "lat" => $data["lat"],
    "lon" => $data["lon"],
    "accuracy" => $data["accuracy"],
    "timestamp" => new MongoDB\BSON\UTCDateTime($data["timestamp"])
];

$db->access_locations->insertOne($doc);

echo json_encode(["ok"=>true]);
