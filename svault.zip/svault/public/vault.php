<?php
require_once __DIR__ . '/../src/config/db.php';
require_once __DIR__ . '/../src/bootstrap.php';
require_once __DIR__ . '/../src/utils/crypto.php';

$user_id = $_GET['user_id'] ?? null;
if (!$user_id) { echo 'Missing user_id parameter — authenticate via QR'; exit; }
try {
    $uid = new MongoDB\BSON\ObjectId($user_id);
} catch (Exception $e) { echo 'invalid user id'; exit; }

// Updated query to exclude soft-deleted passwords
$passwords = $db->passwords->find(['user_id' => $uid, 'deleted_at' => ['$exists' => false]])->toArray();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Secured Vault</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
  /* --------- Colors & layout --------- */
  :root{
    --bg1: #e6f9ff;
    --bg2: #ffffff;
    --accent: #00b4ff;
    --accent-2: #2a9df4;
    --muted: #6b7280;
    --card: #ffffff;
    --glass: rgba(255,255,255,0.75);
    --danger: #e02b2b;
    --success: #10b981;
  }
  *{box-sizing:border-box}
  html,body{height:100%;margin:0;font-family:Inter,system-ui,Segoe UI,Roboto,Arial;background:linear-gradient(135deg,var(--bg1),var(--bg2));background-size:300% 300%;animation:bgFlow 12s linear infinite;color:#072033;}
  @keyframes bgFlow{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}

  /* Topbar */
  .topbar{display:flex;justify-content:space-between;align-items:center;padding:14px 22px;background:rgba(255,255,255,0.9);backdrop-filter:blur(6px);box-shadow:0 6px 20px rgba(8,18,28,0.05);position:sticky;top:0;z-index:30;}
  .topbar .title{font-weight:700;font-size:1.2rem}
  .topbar .controls{display:flex;gap:10px;align-items:center}

  /* Main layout */
  .container{max-width:1200px;margin:22px auto;padding:18px;display:grid;grid-template-columns:260px 1fr;gap:20px}
  @media (max-width:920px){ .container{grid-template-columns:1fr} }

  /* Sidebar */
  .sidebar{background:var(--card);padding:16px;border-radius:12px;box-shadow:0 10px 30px rgba(2,6,12,0.06)}
  .nav{display:block;padding:10px;border-radius:10px;color:var(--accent);text-decoration:none;font-weight:600;margin-bottom:8px}
  .nav:hover{background:#eef9ff}

  /* Grid of password cards */
  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:18px;padding:6px}
  .card{background:var(--card);padding:16px;border-radius:12px;box-shadow:0 8px 24px rgba(8,18,28,0.06);transition:transform .18s ease}
  .card:hover{transform:translateY(-6px)}
  .entry h4{margin:0 0 8px;font-size:1.05rem}
  .masked{font-size:1.4rem;letter-spacing:5px;color:#0b2130;opacity:0.6;margin-bottom:12px}
  .actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}

  /* Search and Filter */
  .search-container {
    margin-bottom: 18px;
    grid-column: 1 / -1;
  }
  .search-input {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 8px;
    font-size: 16px;
    background: var(--card);
    color: #072033;
  }
  .dark .search-input {
    background: rgba(255,255,255,0.1);
    color: #dff6ff;
    border-color: #444;
  }

  /* QR Modal */
  .modal{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(3,7,13,0.42);z-index:80}
  .modal-box{width:380px;background:linear-gradient(180deg,rgba(255,255,255,0.98),#fff);padding:18px;border-radius:12px;box-shadow:0 10px 30px rgba(3,7,13,0.2);text-align:center}
  #qr-area img{width:240px}
  .qr-count{color:var(--muted);font-weight:600;margin-top:8px}

  /* Webcam hologram panel (bottom-left on large screens) */
  .webcam{
  position:fixed;
  left:10px; /* Reduced from 22px */
  bottom:10px; /* Reduced from 22px */
  width:200px; /* Reduced from 320px for a smaller size */
  background:linear-gradient(180deg,rgba(255,255,255,0.92),rgba(255,255,255,0.88));
  padding:8px; /* Slightly reduced padding */
  border-radius:10px; /* Slightly reduced border-radius */
  box-shadow:0 8px 30px rgba(2,6,12,0.12); /* Slightly smaller shadow */
  z-index:70;
}
.webcam .preview{
  position:relative;
  width:100%; /* Changed to 100% to fill the new smaller container width */
  height:100px; /* A fixed height for the preview area */
  border-radius:8px; /* Slightly reduced border-radius */
  overflow:hidden;
  border:1px solid rgba(0,150,220,0.06);
}
#webcam{
  width:100%;
  height:100%;
  object-fit:cover;
  display:block;
}
#overlay{
  position:absolute;
  left:0;
  top:0;
  width:100%; /* Changed to 100% to cover the entire preview area */
  height:100%;
}
#det-status{
  margin-top:6px; /* Slightly reduced margin */
  font-weight:700;
  color:var(--muted);
  text-align:center;
  font-size: 0.8em; /* Made the text slightly smaller */
}

  /* Reveal animated password card (center) */
  .reveal-card{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%) scale(.95);width:360px;border-radius:16px;padding:18px;color:#fff;z-index:90;box-shadow:0 20px 60px rgba(2,6,12,0.35);opacity:0;transition:transform .28s,opacity .28s; display: none;}
  .reveal-card.visible{opacity:1;transform:translate(-50%,-50%) scale(1); display: block;}
  .reveal-inner{padding:6px;border-radius:12px;background:linear-gradient(135deg,#00b4ff,#2a9df4);background-size:200% 200%;animation:revealGrad 6s ease infinite}
  @keyframes revealGrad{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}
  .reveal-title{font-weight:800;font-size:1rem}
  .reveal-pass{font-weight:900;font-family:monospace;font-size:1.6rem;margin:12px 0;letter-spacing:1px}
  .reveal-meta{font-weight:600;opacity:0.95}
  .copy-btn, .close-btn{background:rgba(255,255,255,0.12);border:0;padding:10px 12px;border-radius:10px;color:#fff;font-weight:700;cursor:pointer;transition:transform .12s; margin-left: 8px;}
  .copy-btn:active, .close-btn:active{transform:scale(.98)}

  /* small helper */
  .small-muted{color:var(--muted);font-weight:600}

  /* Success message */
  .success-msg {
    grid-column: 1 / -1;
    background: #ecfdf5;
    color: #065f46;
    padding: 12px;
    border-radius: 8px;
    text-align: center;
    font-weight: 600;
    margin-bottom: 18px;
  }

  /* dark mode */
  .dark body, .dark{ background: linear-gradient(145deg,#071322,#081827);}
  .dark .card{ background: rgba(6,24,38,0.85); color:#dff6ff }
  .dark .sidebar, .dark .modal-box, .dark .webcam { background: rgba(6,24,38,0.85) }
  .dark .masked{ color:#cfeaff }
  .dark .small-muted{ color:#a9dff6 }
  .dark .success-msg { background: #064e3b; color: #d1fae5; }

  /* small UI niceties */
  .btn { background:linear-gradient(90deg,var(--accent),var(--accent-2)); color:white; padding:8px 12px; border-radius:8px; border:0; font-weight:700; cursor:pointer; text-decoration:none; display:inline-block; text-align:center; }
  .btn.small{padding:6px 8px;font-size:.9rem}
  .btn.danger { background: var(--danger); }
</style>
</head>
<body>

<header class="topbar">
  <div class="title">🔐 Secured Vault</div>
  <div class="controls">
    <button id="themeToggle" class="btn small">Toggle Dark</button>
    <a href="lock_vault.php?user_id=<?php echo urlencode($user_id); ?>" class="btn small">Lock</a>
  </div>
</header>

<main class="container">
  <aside class="sidebar">
    <a class="nav" href="add_password.php?user_id=<?php echo $user_id; ?>">➕ Add password</a>
    <a class="nav" href="deleted_passwords.php?user_id=<?php echo $user_id; ?>">🗑️ Recently Deleted</a>
    <a class="nav" href="security_logs.php?user_id=<?php echo $user_id; ?>">📊 Security logs</a>
    <a class="nav" href="strength_analyzer.php?user_id=<?php echo $user_id; ?>">🔍 Password Analyzer</a>
    <a class="nav" href="breach_checker.php?user_id=<?php echo $user_id; ?>">🛡 Breach Checker</a>
    <a class="nav" href="last_access.php?user_id=<?php echo $user_id; ?>">📍 Last Access Map</a>
    <a class="nav" href="session_summary.php?user_id=<?php echo $user_id; ?>">📈 Session Summary</a>
    <p style="margin-top:12px;color:var(--muted);font-weight:600;">Last login: <?php echo date('Y-m-d H:i'); ?></p>
  </aside>

  <section class="grid">
    <div class="search-container">
      <input type="text" id="search-input" class="search-input" placeholder="🔍 Search by site name...">
    </div>
    <?php foreach($passwords as $p): ?>
      <article class="entry card">
        <h4><?php echo htmlentities($p['site_name']); ?></h4>
        <div class="masked">••••••••</div>
        <div class="actions">
          <button class="btn reveal" data-id="<?php echo (string)$p['_id']; ?>">Reveal (Scan QR)</button>
          <button class="btn small danger" onclick="if(confirm('Are you sure you want to delete this password? It cannot be recovered.')) { window.location.href='delete_password.php?user_id=<?php echo $user_id; ?>&password_id=<?php echo (string)$p['_id']; ?>'; } return false;">Delete</button>
        </div>
      </article>
    <?php endforeach; ?>
    <?php if (isset($_GET['deleted'])): ?>
        <div class="success-msg">🗑️ Password moved to Recently Deleted. You can restore it there if needed.</div>
    <?php endif; ?>
  </section>
</main>

<!-- QR Modal -->
<div id="qr-modal" class="modal">
  <div class="modal-box">
    <h3>Scan to reveal</h3>
    <div id="qr-area"></div>
    <div class="qr-count" id="qr-count"></div>
    <p style="margin-top:12px;"><button id="close-qr" class="btn">Close</button></p>
  </div>
</div>

<!-- Webcam preview container -->
<div class="webcam" id="webcam-panel">
  <div class="preview">
    <video id="webcam" autoplay muted playsinline></video>
    <canvas id="overlay"></canvas>
  </div>
  <div id="det-status">Loading camera...</div>
</div>

<!-- Reveal card (password shown here for 12s) -->
<div id="reveal-card" class="reveal-card" aria-hidden="true">
  <div class="reveal-inner">
    <div class="reveal-title">🔓 Password Revealed</div>
    <div id="revealed-pass" class="reveal-pass">••••••••</div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-top:8px;">
      <div id="reveal-timer" class="reveal-meta">12s remaining</div>
      <div style="display:flex; gap:8px;">
        <button id="copy-pass" class="copy-btn">Copy</button>
        <button id="close-reveal" class="close-btn">Close</button>
      </div>
    </div>
  </div>
</div>

<script src="js/vault.js"></script>
<!-- TFJS and model -->
<script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@3.18.0/dist/tf.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@tensorflow-models/coco-ssd"></script>
<script>
function autoLock(reason = "screenshot_attempt") {
    fetch('lock_vault.php?reason=' + reason)
      .then(()=> window.location.href = "index.php");
}

// Detect PrintScreen key
document.addEventListener('keyup', (e)=>{
    if (e.key === "PrintScreen") {
        autoLock("printscreen_key");
    }
});

// Detect Ctrl+P (Print)
document.addEventListener('keydown', (e)=>{
    if (e.ctrlKey && e.key === "p") {
        e.preventDefault();
        autoLock("print_dialog");
    }
});
</script>
<script>
// MASTER AUTO-LOCK
function autoLock(reason = "screenshot_while_password_visible") {
    fetch("lock_vault.php?user_id=<?php echo $user_id; ?>&reason=" + reason)
        .then(() => window.location.href = "index.php");
}

let passwordVisible = false;

// Listen for reveal card activation
document.addEventListener("password_revealed", () => {
    passwordVisible = true;
    let rc = Number(sessionStorage.getItem("reveal_count") || 0);
    rc++;
    sessionStorage.setItem("reveal_count", rc);
    console.log("Reveal Count Updated:", rc);
});

// Listen for reveal card close
document.addEventListener("password_hidden", () => {
    passwordVisible = false;
});

// Close button functionality
document.addEventListener('DOMContentLoaded', () => {
    const closeRevealBtn = document.getElementById('close-reveal');
    if (closeRevealBtn) {
        closeRevealBtn.addEventListener('click', () => {
            const revealCard = document.getElementById('reveal-card');
            revealCard.classList.remove('visible');
            setTimeout(() => {
                revealCard.style.display = 'none';
            }, 280); // Match CSS transition duration
            document.dispatchEvent(new Event('password_hidden'));
        });
    }

    // Search and Filter Functionality
    const searchInput = document.getElementById('search-input');
    const cards = document.querySelectorAll('.entry');
    if (searchInput && cards.length > 0) {
        searchInput.addEventListener('input', (e) => {
            const term = e.target.value.toLowerCase().trim();
            cards.forEach(card => {
                const title = card.querySelector('h4').textContent.toLowerCase();
                card.style.display = title.includes(term) ? '' : 'none';
            });
        });
    }
});

/* ---------- SCREENSHOT / PRINTSCREEN PROTECTION ---------- */

// PrintScreen key
document.addEventListener("keyup", (e)=>{
    if (!passwordVisible) return;
    if (e.key === "PrintScreen") {
        autoLock("printscreen_key");
    }
});

// CTRL+P / CMD+P (Print dialog screenshot)
document.addEventListener("keydown", (e)=>{
    if (!passwordVisible) return;
    if (e.ctrlKey && e.key === "p") {
        e.preventDefault();
        autoLock("print_dialog_screenshot");
    }
});

// Browser hidden (snipping tool / screenshot overlay)
document.addEventListener("visibilitychange", () => {
    if (passwordVisible && document.hidden) {
        autoLock("hidden_tab_screenshot");
    }
});

// DevTools screenshot attempts
setInterval(()=>{
    if (!passwordVisible) return;
    if (window.outerHeight - window.innerHeight > 180) {
        autoLock("devtools_screenshot");
    }
}, 700);

// Suspicious screen resize (snipping tool UI)
let lastW = window.innerWidth;
let lastH = window.innerHeight;

setInterval(()=>{
    if (!passwordVisible) return;

    if (Math.abs(window.innerWidth - lastW) > 100 ||
        Math.abs(window.innerHeight - lastH) > 100) {
        autoLock("snipping_tool_resize");
    }
    lastW = window.innerWidth;
    lastH = window.innerHeight;
}, 600);
</script>
<script>
/* PANIC MODE SNIPPET
   - Triple SHIFT quickly OR custom key combo triggers panic
*/
(function(){
  let shiftSeq = [];
  const MAX_WINDOW = 1500; // ms for triple shift
  const MAX_PRESS_INTERVAL = 700;
  let lastShiftTime = 0;
  let failPinCount = 0;
  const FAIL_PIN_THRESHOLD = 3;

  function triggerPanic(reason){
    // optional: set a local flag to wipe any sensitive client storage
    try { localStorage.setItem('panic_mode', '1'); } catch(e){}
    // call server lock with panic param
    fetch("lock_vault.php?user_id=<?php echo urlencode($user_id); ?>&reason=" + reason + "&panic=1").finally(()=>{
      // redirect to index
      window.location.href = "index.php";
    });
  }

  // Listen for SHIFT presses
  document.addEventListener('keydown', (e)=>{
    if (e.key === 'Shift') {
      const now = Date.now();
      if (now - lastShiftTime > MAX_PRESS_INTERVAL) {
        shiftSeq = []; // reset if slow
      }
      shiftSeq.push(now);
      lastShiftTime = now;
      // Keep only latest 3
      if (shiftSeq.length > 3) shiftSeq.shift();
      if (shiftSeq.length === 3 && (shiftSeq[2] - shiftSeq[0]) <= MAX_WINDOW) {
        // triple-shift detected
        triggerPanic('triple_shift_hotkey');
      }
    }

    // Optional alt combo: P + A + N held together triggers panic
    if (e.key === 'P' || e.key === 'p') window._p = true;
    if (e.key === 'A' || e.key === 'a') window._a = true;
    if (e.key === 'N' || e.key === 'n') window._n = true;
    if (window._p && window._a && window._n) {
      triggerPanic('pan_combo');
    }
  });

  document.addEventListener('keyup', (e)=>{
    if (e.key === 'P' || e.key === 'p') window._p = false;
    if (e.key === 'A' || e.key === 'a') window._a = false;
    if (e.key === 'N' || e.key === 'n') window._n = false;
  });

  // Helper: call from your PIN flow to register a failed attempt
  window.registerFailedPinAttempt = function(){
    failPinCount++;
    if (failPinCount >= FAIL_PIN_THRESHOLD) {
      triggerPanic('failed_pin_threshold');
    }
  };

  // Optional: clear panic flag after logout/lock
  window.clearPanicLocal = function(){ try{ localStorage.removeItem('panic_mode'); }catch(e){} };
})();

// --- Accurate Location Logger (GPS-based) ---
function saveAccurateLocation(userId) {
    if (!navigator.geolocation) {
        console.log("Geolocation not supported");
        return;
    }

    navigator.geolocation.getCurrentPosition(
        (pos) => {
            const payload = {
                user_id: userId,
                lat: pos.coords.latitude,
                lon: pos.coords.longitude,
                accuracy: pos.coords.accuracy,
                timestamp: Date.now()
            };

            fetch("save_location.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            }).then(res => res.json())
              .then(j => console.log("Location saved:", j));
        },
        (err) => {
            console.log("Location denied or failed:", err);
        },
        { enableHighAccuracy: true, timeout: 8000 }
    );
}

// call when vault loads
saveAccurateLocation("<?php echo $user_id; ?>");

  
</script>


</body>
</html>