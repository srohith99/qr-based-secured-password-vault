<?php
// download_report.php
require_once __DIR__ . '/../src/config/db.php';

$report_id = $_GET['report_id'] ?? null;
if (!$report_id) { http_response_code(400); echo "Missing report_id"; exit; }

try {
    $rid = new MongoDB\BSON\ObjectId($report_id);
} catch (Exception $e) {
    http_response_code(400); echo "Invalid report_id"; exit;
}

$doc = $db->session_reports->findOne(['_id' => $rid]);
if (!$doc) { http_response_code(404); echo "Report not found"; exit; }

$body = $doc['body'] ?? "Report empty";
$created = isset($doc['created_at']) ? $doc['created_at']->toDateTime()->format('Ymd_His') : date('Ymd_His');
$filename = "session_report_{$report_id}_{$created}.txt";

header('Content-Type: text/plain; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
echo $body;
exit;
