<?php
require_once __DIR__ . '/../src/bootstrap.php';
$registered = isset($_GET['registered']);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Login — Secured Vault</title>

<style>
/* GOOGLE FONT */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800&display=swap');

*{
  margin:0; padding:0;
  box-sizing:border-box;
  font-family:"Poppins",sans-serif;
}

body{
  height:100vh;
  overflow:hidden;
  background:#02050a;
  color:white;
}

/* ░░░░ ULTRA ANIMATED GRADIENT BACKGROUND ░░░░ */
.bg-gradient{
  position:fixed;
  top:0; left:0;
  width:200%; height:200%;
  background:linear-gradient(130deg,#000a16,#00182f,#003d74,#008eff,#00f6ff);
  background-size:400% 400%;
  animation:gradientFlow 16s ease-in-out infinite;
  filter:blur(160px);
  z-index:-3;
}

@keyframes gradientFlow{
  0%{background-position:0% 50%;}
  50%{background-position:100% 50%;}
  100%{background-position:0% 50%;}
}

/* ░░░░ CYBER GRID OVERLAY ░░░░ */
.grid-overlay{
  position:fixed;
  inset:0;
  background-image:
    linear-gradient(rgba(255,255,255,0.04) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255,255,255,0.04) 1px, transparent 1px);
  background-size:46px 46px;
  z-index:-2;
}

/* PARTICLE CANVAS */
#particles{
  position:fixed;
  inset:0;
  z-index:-1;
}

/* MAIN LAYOUT */
.login-wrapper{
  height:100vh;
  display:flex;
  align-items:center;
  justify-content:center;
  padding:20px;
}

/* ░░░░ GLASS CARD STYLE ░░░░ */
.login-card{
  width:390px;
  padding:28px;
  border-radius:20px;
  background:rgba(255,255,255,0.1);
  backdrop-filter:blur(18px);
  border:1px solid rgba(0,255,255,0.2);
  box-shadow:0 4px 40px rgba(0,200,255,0.25);
  animation:float 7s ease-in-out infinite;
  transition:0.3s;
}

@keyframes float{
  0%{transform:translateY(0);}
  50%{transform:translateY(-12px);}
  100%{transform:translateY(0);}
}

.title{
  font-size:26px;
  font-weight:800;
  text-align:center;
  margin-bottom:2px;
  color:#00eaff;
}

.subtitle{
  text-align:center;
  font-size:14px;
  color:#bdefff;
  margin-bottom:16px;
}

.notice{
  padding:10px;
  border-left:4px solid #00eaff;
  background:rgba(0,102,146,0.4);
  border-radius:6px;
  margin-bottom:14px;
  color:#aef3ff;
}

.form label{
  font-weight:600;
  margin-top:14px;
  display:block;
}

.form input{
  width:100%;
  padding:10px;
  margin-top:5px;
  background:rgba(255,255,255,0.12);
  border:1px solid rgba(255,255,255,0.25);
  border-radius:8px;
  color:white;
  outline:none;
  font-size:15px;
}

.form input:focus{
  border-color:#00eaff;
  box-shadow:0 0 12px #00d5ff99;
}

.btn-login{
  width:100%;
  margin-top:18px;
  padding:13px;
  border:none;
  border-radius:10px;
  background:linear-gradient(115deg,#00d5ff,#0078ff);
  font-size:15px;
  font-weight:700;
  cursor:pointer;
  color:white;
  transition:0.25s ease;
}

.btn-login:hover{
  transform:scale(1.05);
  box-shadow:0 0 18px #00eaffaa;
}

.info{
  margin-top:16px;
  text-align:center;
  font-size:13px;
  color:#d8f3ff;
  opacity:0.85;
}
</style>

</head>

<body>

<!-- Background layers -->
<div class="bg-gradient"></div>
<div class="grid-overlay"></div>
<canvas id="particles"></canvas>

<!-- Login Card -->
<div class="login-wrapper">
  <section class="login-card">

    <h1 class="title">🔐 Secured Vault</h1>
    <p class="subtitle">Ultra-Secure QR Authentication</p>

    <?php if ($registered): ?>
      <div class="notice">✔ Registered successfully — Please sign in.</div>
    <?php endif; ?>

    <form method="POST" action="login_handler.php" class="form">
      <label>Username</label>
      <input name="username" required>

      <label>Password</label>
      <input type="password" name="password" required>

      <button class="btn-login">Continue → Generate QR</button>
    </form>

    <p class="info">Dynamic QR (30s), AES + Secure Validation.</p>

  </section>
</div>

<!-- PARTICLES SCRIPT -->
<script>
const canvas = document.getElementById("particles");
const ctx = canvas.getContext("2d");

let w, h;
function resize(){
  w = canvas.width = window.innerWidth;
  h = canvas.height = window.innerHeight;
}
resize();
window.onresize = resize;

let particles = [];
for(let i=0;i<80;i++){
  particles.push({
    x: Math.random()*w,
    y: Math.random()*h,
    r: Math.random()*2 + 1,
    dx: (Math.random() - 0.5) * 0.6,
    dy: (Math.random() - 0.5) * 0.6,
  });
}

function draw(){
  ctx.clearRect(0,0,w,h);

  particles.forEach(p=>{
    ctx.beginPath();
    ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
    ctx.fillStyle = "#00eaff";
    ctx.fill();

    p.x += p.dx;
    p.y += p.dy;

    if(p.x < 0 || p.x > w) p.dx *= -1;
    if(p.y < 0 || p.y > h) p.dy *= -1;
  });

  requestAnimationFrame(draw);
}
draw();
</script>

</body>
</html>
