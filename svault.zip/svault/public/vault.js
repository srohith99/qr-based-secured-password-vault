document.addEventListener('DOMContentLoaded', async ()=>{
  document.querySelectorAll('.reveal').forEach(btn=>{
    btn.addEventListener('click', async ()=>{
      const pid = btn.dataset.id;
      const urlParams = new URLSearchParams(location.search);
      const user_id = urlParams.get('user_id') || '1';
      const resp = await fetch(`reveal_request.php?password_id=${pid}&user_id=${user_id}`);
      const json = await resp.json();
      if (json.ok) {
        openQrModal(json);
        pollQr(json.token);
      }
    });
  });

  function openQrModal(json){
    const modal = document.getElementById('qr-modal');
    document.getElementById('qr-area').innerText = json.payload;
    document.getElementById('qr-timer').innerText = 'Expires: ' + json.expires;
    modal.style.display='flex';
    document.getElementById('close-qr').onclick = ()=> modal.style.display='none';
  }

  async function pollQr(token){
    const interval = setInterval(async ()=>{
      const r = await fetch('poll_qr_status.php?token='+token);
      const j = await r.json();
      if (j.revealed) {
        clearInterval(interval);
        alert('Password: ' + j.password);
        document.getElementById('qr-modal').style.display='none';
      }
    }, 1500);
    setTimeout(()=> clearInterval(interval), 35000);
  }

  // TF.js detection
  const video = document.getElementById('webcam');
  const canvas = document.getElementById('overlay');
  const ctx = canvas.getContext('2d');
  async function setupCamera(){
    try {
      const stream = await navigator.mediaDevices.getUserMedia({video:true});
      video.srcObject = stream;
      await new Promise(res => video.onloadedmetadata = res);
      return true;
    } catch(e){ console.warn('camera:', e); return false; }
  }
  if (await setupCamera()){
    const model = await cocoSsd.load();
    (async function loop(){
      const preds = await model.detect(video);
      ctx.clearRect(0,0,canvas.width, canvas.height);
      let alertFound = false;
      preds.forEach(p=>{
        const [x,y,w,h] = p.bbox;
        ctx.strokeStyle = 'red';
        ctx.lineWidth = 2;
        ctx.strokeRect(x,y,w,h);
        ctx.fillStyle = 'red';
        ctx.fillText(p.class + ' ' + Math.round(p.score*100)+'%', x, y-6);
        if (p.class === 'person' || p.class === 'cell phone' || p.class==='mobile phone') alertFound = true;
      });
      if (alertFound) {
        document.getElementById('det-status').innerText = 'Person/Phone detected — locking...';
        // log to server and redirect (force lock)
        fetch('detection_trigger.php', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({user_id:1, predictions:preds})})
          .then(()=> setTimeout(()=> location.href='index.php', 800));
      } else {
        document.getElementById('det-status').innerText = 'No person detected';
      }
      requestAnimationFrame(loop);
    })();
  }
});
