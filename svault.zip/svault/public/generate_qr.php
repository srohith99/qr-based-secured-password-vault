<?php
require_once __DIR__ . '/../src/config/db.php';
require_once __DIR__ . '/../src/bootstrap.php';
require_once __DIR__ . '/../src/utils/qr.php';

$token = $_GET['token'] ?? '';
if (!$token) die('no token');

$qrDoc = $db->qr_sessions->findOne(['token'=>$token]);
if (!$qrDoc) die('invalid token');

$payload = $token;
$img = build_qr_dataurl($payload);
$expires_at = $qrDoc['expires_at']->toDateTime()->format(DATE_ATOM);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>QR Authentication — Secured Vault</title>

<style>
/* GOOGLE FONT */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800&display=swap');

*{
  margin:0;
  padding:0;
  box-sizing:border-box;
  font-family:"Poppins",sans-serif;
}

body{
  height:100vh;
  overflow:hidden;
  background:#02050a;
  color:white;
}

/* ░░░░ ULTRA ANIMATED NEON GRADIENT ░░░░ */
.bg-gradient{
  position:fixed;
  top:0; left:0;
  width:200%; height:200%;
  background:linear-gradient(130deg,#001322,#003c74,#0065d6,#00d5ff,#00f6ff);
  background-size:400% 400%;
  animation:flow 16s ease-in-out infinite;
  filter:blur(180px);
  z-index:-3;
}
@keyframes flow{
  0%{background-position:0% 50%;}
  50%{background-position:100% 50%;}
  100%{background-position:0% 50%;}
}

/* CYBER GRID LINES */
.grid-overlay{
  position:fixed;
  inset:0;
  background-image:
    linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px);
  background-size:46px 46px;
  z-index:-2;
}

/* PARTICLES */
#particles{
  position:fixed;
  inset:0;
  z-index:-1;
}

/* MAIN LAYOUT */
.center-wrapper{
  height:100vh;
  display:flex;
  align-items:center;
  justify-content:center;
  padding:20px;
}

/* GLASS CARD */
.qr-card{
  width:420px;
  padding:26px 28px;
  border-radius:20px;
  background:rgba(255,255,255,0.10);
  backdrop-filter:blur(20px);
  border:1px solid rgba(0,255,255,0.20);
  box-shadow:0 6px 40px rgba(0,200,255,0.35);
  text-align:center;
  animation:float 7s ease-in-out infinite;
}

@keyframes float{
  0%{transform:translateY(0);}
  50%{transform:translateY(-10px);}
  100%{transform:translateY(0);}
}

h2{
  font-size:24px;
  font-weight:700;
  color:#00eaff;
  margin-bottom:10px;
}

.qr-img{
  margin:18px auto;
  width:260px; height:260px;
  border-radius:12px;
  border:2px solid #00eaff55;
  padding:8px;
  background:rgba(255,255,255,0.15);
  box-shadow:0 0 16px #00eaff66;
}

.expire-text{
  margin-top:10px;
  color:#bfefff;
  font-size:14px;
  font-weight:600;
}

.hint{
  margin-top:12px;
  font-size:12.5px;
  color:#d6f6ff;
  opacity:0.8;
}
</style>

</head>
<body>

<!-- Background -->
<div class="bg-gradient"></div>
<div class="grid-overlay"></div>
<canvas id="particles"></canvas>

<!-- Center UI -->
<div class="center-wrapper">

  <div class="qr-card">

    <h2>📱 Scan to Authenticate</h2>

    <img src="<?php echo $img; ?>" class="qr-img" alt="QR Code">

    <div class="expire-text">
      Expires at: <br>
      <strong><?php echo htmlentities($expires_at); ?></strong>
    </div>

    <p class="hint">
      Scan this QR with your registered device.  
      Verification POST → <b>verify_mobile.php</b>
    </p>

  </div>

</div>

<script>
/* ───── PARTICLES ANIMATION ───── */
const canvas = document.getElementById("particles");
const ctx = canvas.getContext("2d");

let w, h;
function resize(){
  w = canvas.width = window.innerWidth;
  h = canvas.height = window.innerHeight;
}
resize();
window.onresize = resize;

let particles = [];
for(let i=0;i<80;i++){
  particles.push({
    x: Math.random()*w,
    y: Math.random()*h,
    r: Math.random()*2 + 1,
    dx: (Math.random() - 0.5) * 0.6,
    dy: (Math.random() - 0.5) * 0.6,
  });
}

function draw(){
  ctx.clearRect(0,0,w,h);

  particles.forEach(p=>{
    ctx.beginPath();
    ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
    ctx.fillStyle = "#00eaff";
    ctx.fill();

    p.x += p.dx;
    p.y += p.dy;

    if(p.x < 0 || p.x > w) p.dx *= -1;
    if(p.y < 0 || p.y > h) p.dy *= -1;
  });

  requestAnimationFrame(draw);
}
draw();

/* ───── POLLING QR STATUS ───── */
let token = "<?php echo $token; ?>";

async function pollStatus() {
    const res = await fetch("poll_login_status.php?token=" + token);
    const json = await res.json();

    if (json.verified === true) {
        window.location.href = "vault.php?user_id=" + json.user_id;
    } else {
        setTimeout(pollStatus, 1500);
    }
}
pollStatus();
</script>

</body>
</html>
