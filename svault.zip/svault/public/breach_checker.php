<?php
$user_id = $_GET['user_id'] ?? null;
if (!$user_id) { echo "Missing user_id"; exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Breach Checker</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
:root {
  --bg:#05070d;
  --card:#0f1622;
  --border:#1a2333;
  --text:#d7ecff;
  --neon:#00eaff;
  --glow:0 0 12px #00eaff55;
}
body {
  margin:0;
  background:radial-gradient(circle at top, #0a111a, #02040a 70%);
  font-family:Inter, sans-serif;
  color:var(--text);
}
.topbar{
  padding:16px 24px;
  background:#060b12;
  border-bottom:1px solid var(--neon);
  display:flex;
  justify-content:space-between;
  align-items:center;
  box-shadow:var(--glow);
}
.title{font-weight:800;font-size:1.3rem;color:var(--neon);text-shadow:var(--glow);}
.btn{
  padding:8px 14px;
  border:1px solid var(--neon);
  background:transparent;
  color:var(--neon);
  border-radius:8px;
  font-weight:700;
  cursor:pointer;
  text-decoration:none;
}
.btn:hover{background:var(--neon);color:black;box-shadow:var(--glow);}
.container{
  max-width:760px;
  margin:40px auto;
  padding:20px;
  background:var(--card);
  border:1px solid var(--border);
  border-radius:12px;
  box-shadow:0 0 20px #00b7ff22;
}
.input {
  width:100%;
  padding:12px;
  background:#060b14;
  border:1px solid var(--border);
  border-radius:8px;
  color:var(--text);
  font-family:monospace;
  font-size:1rem;
}
.result-box{
  margin-top:20px;
  padding:14px;
  border-radius:10px;
  background:#07111c;
  border:1px solid var(--border);
}
.good{color:#00ffb7;font-weight:700;}
.bad{color:#ff3b6b;font-weight:700;}
</style>
</head>
<body>

<header class="topbar">
  <div class="title">🛡 Breach Checker</div>
  <a href="vault.php?user_id=<?php echo urlencode($user_id); ?>" class="btn">Back to Vault</a>
</header>

<main class="container">
  <label>Enter any password (won’t be sent to server):</label>
  <input id="pw" type="password" class="input" placeholder="Type password..." autocomplete="off">

  <button id="checkBtn" class="btn" style="margin-top:12px;">Check Breach</button>

  <div id="result" class="result-box" style="display:none;"></div>
</main>

<script>
// SHA-1 function
async function sha1(str){
  const buf = new TextEncoder().encode(str);
  const digest = await crypto.subtle.digest("SHA-1", buf);
  return Array.from(new Uint8Array(digest)).map(x=>x.toString(16).padStart(2,"0")).join("").toUpperCase();
}

document.getElementById("checkBtn").addEventListener("click", async () => {
  const pw = document.getElementById("pw").value.trim();
  const box = document.getElementById("result");

  if (!pw) {
    box.style.display="block";
    box.innerHTML="<span class='bad'>Enter a password first.</span>";
    return;
  }

  // Step 1: Hash it
  const hash = await sha1(pw);
  const prefix = hash.substring(0,5);
  const suffix = hash.substring(5);

  // Step 2: Call HIBP range API (returns hash suffix + count list)
  const response = await fetch("https://api.pwnedpasswords.com/range/" + prefix);
  const text = await response.text();

  // Step 3: Check if suffix exists
  const lines = text.split("\n");
  let found = false;
  let count = 0;

  for (const line of lines) {
    const [suff, cnt] = line.split(":");
    if (suff.trim() === suffix) {
      found = true;
      count = parseInt(cnt);
      break;
    }
  }

  box.style.display="block";

  if (found) {
    box.innerHTML = `
      <div class="bad">⚠ This password has appeared in <strong>${count.toLocaleString()}</strong> breaches.</div>
      <p>This password is unsafe to use anywhere.</p>
    `;
  } else {
    box.innerHTML = `
      <div class="good">✔ No breach found for this password.</div>
      <p>It has not appeared in known leaks — but still ensure it's strong.</p>
    `;
  }
});
</script>

</body>
</html>
